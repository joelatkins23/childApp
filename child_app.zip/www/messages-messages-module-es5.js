function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["messages-messages-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/messages/messages.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/messages/messages.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMessagesMessagesPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n        <ion-title>messages</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-icon name=\"search\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-list (click)=\"goto('messagedetail')\">\n        <ion-item>\n            <ion-avatar>\n                <img src=\"../../assets/images/img-avataa.png\">\n            </ion-avatar>\n            <div class=\"r_content\">\n                <ion-list class=\"massages_list\">\n                    <ion-text>\n                        Message 1\n                        <ion-label>(Adminstration Center)</ion-label>\n                    </ion-text>\n                    <ion-label class=\"msg_time\">8:50 PM</ion-label>\n                </ion-list>\n                <ion-list class=\"massages_des\">\n                    <ion-text>Lorem Ipsum is simply dummy text of the printing and typesetting</ion-text>\n                    <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n                </ion-list>\n            </div>\n        </ion-item>\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/messages/messages-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/messages/messages-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: MessagesPageRoutingModule */

  /***/
  function srcAppMessagesMessagesRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MessagesPageRoutingModule", function () {
      return MessagesPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _messages_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./messages.page */
    "./src/app/messages/messages.page.ts");

    var routes = [{
      path: '',
      component: _messages_page__WEBPACK_IMPORTED_MODULE_3__["MessagesPage"]
    }];

    var MessagesPageRoutingModule = function MessagesPageRoutingModule() {
      _classCallCheck(this, MessagesPageRoutingModule);
    };

    MessagesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MessagesPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/messages/messages.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/messages/messages.module.ts ***!
    \*********************************************/

  /*! exports provided: MessagesPageModule */

  /***/
  function srcAppMessagesMessagesModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MessagesPageModule", function () {
      return MessagesPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _messages_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./messages-routing.module */
    "./src/app/messages/messages-routing.module.ts");
    /* harmony import */


    var _messages_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./messages.page */
    "./src/app/messages/messages.page.ts");

    var MessagesPageModule = function MessagesPageModule() {
      _classCallCheck(this, MessagesPageModule);
    };

    MessagesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _messages_routing_module__WEBPACK_IMPORTED_MODULE_5__["MessagesPageRoutingModule"]],
      declarations: [_messages_page__WEBPACK_IMPORTED_MODULE_6__["MessagesPage"]]
    })], MessagesPageModule);
    /***/
  },

  /***/
  "./src/app/messages/messages.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/messages/messages.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppMessagesMessagesPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\nion-avatar {\n  width: 50px;\n  height: 50px;\n}\n\nion-item {\n  margin-right: 15px;\n  --inner-padding-end: 0px;\n}\n\n.r_content {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-direction: column;\n  padding: 0;\n  width: calc(100% - 50px);\n  margin-left: 10px;\n}\n\n.massages_list {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  font-size: 14px;\n  font-weight: 500;\n  padding: 0;\n  margin-bottom: 10px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.massages_list ion-text {\n  color: #187bad;\n  width: 80%;\n  display: flex;\n  font-size: 14px;\n}\n\n.massages_list ion-label {\n  color: #8d8d8d;\n  font-size: 14px;\n  display: inherit;\n}\n\n.massages_list .msg_time {\n  color: #187bad !important;\n  text-align: right;\n  font-size: 14px;\n}\n\nion-list {\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.massages_des {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  font-size: 14px;\n  font-weight: 500;\n  padding: 0;\n  margin-bottom: 10px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.massages_des ion-text {\n  color: #8d8d8d;\n  width: 80%;\n  display: flex;\n  font-size: 14px;\n}\n\n.massages_des img {\n  width: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZXMvRDpcXHRhc2tcXDIwMjAwNzA3XFx3b3JrXFxjaGlsZF9hcHAvc3JjXFxhcHBcXG1lc3NhZ2VzXFxtZXNzYWdlcy5wYWdlLnNjc3MiLCJzcmMvYXBwL21lc3NhZ2VzL21lc3NhZ2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNDQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLDREQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0Esd0JBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0VBQ0Esd0JBQUE7RUFDQSxpQkFBQTtBQ0NKOztBREVBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsNERBQUE7QUNDSjs7QURBSTtFQUNJLGNBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7QUNFUjs7QURBSTtFQUNJLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUNFUjs7QURBSTtFQUNJLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FDRVI7O0FERUE7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSw0REFBQTtBQ0NKOztBREFJO0VBQ0ksY0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0VSOztBREFJO0VBQ0ksV0FBQTtBQ0VSIiwiZmlsZSI6InNyYy9hcHAvbWVzc2FnZXMvbWVzc2FnZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZycpO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuaW9uLXRpdGxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1idXR0b25zIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG5pb24tYXZhdGFyIHtcclxuICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbn1cclxuXHJcbi5yX2NvbnRlbnQge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICB3aWR0aDogY2FsYygxMDAlIC0gNTBweCk7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxufVxyXG5cclxuLm1hc3NhZ2VzX2xpc3Qge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgIGlvbi10ZXh0IHtcclxuICAgICAgICBjb2xvcjogIzE4N2JhZDtcclxuICAgICAgICB3aWR0aDogODAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgfVxyXG4gICAgaW9uLWxhYmVsIHtcclxuICAgICAgICBjb2xvcjogIzhkOGQ4ZDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgZGlzcGxheTogaW5oZXJpdDtcclxuICAgIH1cclxuICAgIC5tc2dfdGltZSB7XHJcbiAgICAgICAgY29sb3I6ICMxODdiYWQgIWltcG9ydGFudDtcclxuICAgICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbn1cclxuXHJcbi5tYXNzYWdlc19kZXMge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgIGlvbi10ZXh0IHtcclxuICAgICAgICBjb2xvcjogIzhkOGQ4ZDtcclxuICAgICAgICB3aWR0aDogODAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgfVxyXG4gICAgaW1nIHtcclxuICAgICAgICB3aWR0aDogMjVweDtcclxuICAgIH1cclxufSIsImlvbi1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbmlvbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbmlvbi1hdmF0YXIge1xuICB3aWR0aDogNTBweDtcbiAgaGVpZ2h0OiA1MHB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xufVxuXG4ucl9jb250ZW50IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgcGFkZGluZzogMDtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDUwcHgpO1xuICBtYXJnaW4tbGVmdDogMTBweDtcbn1cblxuLm1hc3NhZ2VzX2xpc3Qge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cbi5tYXNzYWdlc19saXN0IGlvbi10ZXh0IHtcbiAgY29sb3I6ICMxODdiYWQ7XG4gIHdpZHRoOiA4MCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYXNzYWdlc19saXN0IGlvbi1sYWJlbCB7XG4gIGNvbG9yOiAjOGQ4ZDhkO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGRpc3BsYXk6IGluaGVyaXQ7XG59XG4ubWFzc2FnZXNfbGlzdCAubXNnX3RpbWUge1xuICBjb2xvcjogIzE4N2JhZCAhaW1wb3J0YW50O1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuXG5pb24tbGlzdCB7XG4gIHBhZGRpbmctdG9wOiAxMHB4O1xuICBwYWRkaW5nLWJvdHRvbTogMTBweDtcbn1cblxuLm1hc3NhZ2VzX2RlcyB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuLm1hc3NhZ2VzX2RlcyBpb24tdGV4dCB7XG4gIGNvbG9yOiAjOGQ4ZDhkO1xuICB3aWR0aDogODAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmb250LXNpemU6IDE0cHg7XG59XG4ubWFzc2FnZXNfZGVzIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/messages/messages.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/messages/messages.page.ts ***!
    \*******************************************/

  /*! exports provided: MessagesPage */

  /***/
  function srcAppMessagesMessagesPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MessagesPage", function () {
      return MessagesPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var MessagesPage = /*#__PURE__*/function () {
      function MessagesPage(platform, navCtrl) {
        _classCallCheck(this, MessagesPage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.pt_active = false;
      }

      _createClass(MessagesPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }, {
        key: "goto",
        value: function goto(p) {
          this.navCtrl.navigateForward(p);
        }
      }]);

      return MessagesPage;
    }();

    MessagesPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    MessagesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-messages',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./messages.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/messages/messages.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./messages.page.scss */
      "./src/app/messages/messages.page.scss"))["default"]]
    })], MessagesPage);
    /***/
  }
}]);
//# sourceMappingURL=messages-messages-module-es5.js.map