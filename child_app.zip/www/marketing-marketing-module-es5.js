function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["marketing-marketing-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/marketing/marketing.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/marketing/marketing.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppMarketingMarketingPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n        <ion-title>Marketing</ion-title>\n    </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-list class=\"market\">\n        <ion-text class=\"market_header\">\n            Send us a message!\n        </ion-text>\n    </ion-list>\n    <ion-list class=\"market mt-20\">\n        <ion-text class=\"market_title\">\n            How is the app working ?\n        </ion-text>\n        <ion-textarea class=\"market_textarea\" rows=\"6\" cols=\"20\" placeholder=\"Write Comment\"></ion-textarea>\n    </ion-list>\n    <ion-list class=\"market mt-20\">\n        <ion-text class=\"market_title\">\n            What do you expect from the app ?\n        </ion-text>\n        <ion-textarea class=\"market_textarea\" rows=\"6\" cols=\"20\" placeholder=\"Write Comment\"></ion-textarea>\n    </ion-list>\n    <ion-list class=\"market mt-20\">\n        <ion-button class=\"btn-market\" expand=\"block\">Submit</ion-button>\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/marketing/marketing-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/marketing/marketing-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: MarketingPageRoutingModule */

  /***/
  function srcAppMarketingMarketingRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MarketingPageRoutingModule", function () {
      return MarketingPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _marketing_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./marketing.page */
    "./src/app/marketing/marketing.page.ts");

    var routes = [{
      path: '',
      component: _marketing_page__WEBPACK_IMPORTED_MODULE_3__["MarketingPage"]
    }];

    var MarketingPageRoutingModule = function MarketingPageRoutingModule() {
      _classCallCheck(this, MarketingPageRoutingModule);
    };

    MarketingPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MarketingPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/marketing/marketing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/marketing/marketing.module.ts ***!
    \***********************************************/

  /*! exports provided: MarketingPageModule */

  /***/
  function srcAppMarketingMarketingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MarketingPageModule", function () {
      return MarketingPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _marketing_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./marketing-routing.module */
    "./src/app/marketing/marketing-routing.module.ts");
    /* harmony import */


    var _marketing_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./marketing.page */
    "./src/app/marketing/marketing.page.ts");

    var MarketingPageModule = function MarketingPageModule() {
      _classCallCheck(this, MarketingPageModule);
    };

    MarketingPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _marketing_routing_module__WEBPACK_IMPORTED_MODULE_5__["MarketingPageRoutingModule"]],
      declarations: [_marketing_page__WEBPACK_IMPORTED_MODULE_6__["MarketingPage"]]
    })], MarketingPageModule);
    /***/
  },

  /***/
  "./src/app/marketing/marketing.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/marketing/marketing.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppMarketingMarketingPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\n.market {\n  padding: 0 10px;\n  margin-top: 10px;\n}\n\n.market_header {\n  color: #4c4c4c;\n  font-weight: 600;\n  font-size: 16px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.market_title {\n  color: #4f4f4f;\n  font-weight: 500;\n  font-size: 16px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.market_textarea {\n  font-size: 14px;\n  color: #a3a3a3;\n  border: 1px solid #d7d7d7;\n  padding: 5px;\n  margin: 10px 0;\n  border-radius: 10px;\n}\n\n.btn-market {\n  --background: #187bad;\n  width: 100%;\n  color: white;\n  text-transform: initial;\n  font-size: 16px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWFya2V0aW5nL0Q6XFx0YXNrXFwyMDIwMDcwN1xcd29ya1xcY2hpbGRfYXBwL3NyY1xcYXBwXFxtYXJrZXRpbmdcXG1hcmtldGluZy5wYWdlLnNjc3MiLCJzcmMvYXBwL21hcmtldGluZy9tYXJrZXRpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7RUFDQSxzQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsNERBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7QUNDSjs7QURFQTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSw0REFBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLDREQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQ0NKOztBREVBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLDREQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9tYXJrZXRpbmcvbWFya2V0aW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmcnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuXHJcbmlvbi10aXRsZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLm1hcmtldCB7XHJcbiAgICBwYWRkaW5nOiAwIDEwcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG59XHJcblxyXG4ubWFya2V0X2hlYWRlciB7XHJcbiAgICBjb2xvcjogIzRjNGM0YztcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1hcmtldF90aXRsZSB7XHJcbiAgICBjb2xvcjogIzRmNGY0ZjtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm1hcmtldF90ZXh0YXJlYSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogI2EzYTNhMztcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICBtYXJnaW46IDEwcHggMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5idG4tbWFya2V0IHtcclxuICAgIC0tYmFja2dyb3VuZDogIzE4N2JhZDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxufSIsImlvbi1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbmlvbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5tYXJrZXQge1xuICBwYWRkaW5nOiAwIDEwcHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG59XG5cbi5tYXJrZXRfaGVhZGVyIHtcbiAgY29sb3I6ICM0YzRjNGM7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG5cbi5tYXJrZXRfdGl0bGUge1xuICBjb2xvcjogIzRmNGY0ZjtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLm1hcmtldF90ZXh0YXJlYSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICNhM2EzYTM7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XG4gIHBhZGRpbmc6IDVweDtcbiAgbWFyZ2luOiAxMHB4IDA7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5cbi5idG4tbWFya2V0IHtcbiAgLS1iYWNrZ3JvdW5kOiAjMTg3YmFkO1xuICB3aWR0aDogMTAwJTtcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/marketing/marketing.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/marketing/marketing.page.ts ***!
    \*********************************************/

  /*! exports provided: MarketingPage */

  /***/
  function srcAppMarketingMarketingPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MarketingPage", function () {
      return MarketingPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var MarketingPage = /*#__PURE__*/function () {
      function MarketingPage(platform, navCtrl) {
        _classCallCheck(this, MarketingPage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.pt_active = false;
      }

      _createClass(MarketingPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }]);

      return MarketingPage;
    }();

    MarketingPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    MarketingPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-marketing',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./marketing.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/marketing/marketing.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./marketing.page.scss */
      "./src/app/marketing/marketing.page.scss"))["default"]]
    })], MarketingPage);
    /***/
  }
}]);
//# sourceMappingURL=marketing-marketing-module-es5.js.map