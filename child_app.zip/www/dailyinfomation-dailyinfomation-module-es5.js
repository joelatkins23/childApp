function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dailyinfomation-dailyinfomation-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dailyinfomation/dailyinfomation.page.html":
  /*!*************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dailyinfomation/dailyinfomation.page.html ***!
    \*************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDailyinfomationDailyinfomationPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n        <ion-title>Child Daily Information</ion-title>\n    </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-list class=\"childDaily\">\n        <ion-list class=\"childDaily__list\">\n            <ion-text class=\"childDaily__title\">How often to eat</ion-text>\n            <ion-radio-group value=\"0 Times\" (ionChange)=\"getData($event.detail.value)\">\n                <ion-list class=\"childDaily__radio\">\n                    <ion-item class=\"childDaily__radio-item ion-no-padding\" lines=\"none\">\n                        <ion-radio class=\"childDaily__rdo\" value=\"0 Times\"></ion-radio>\n                        <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.eat=='0 Times' ? 'childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                        <ion-label class=\"childDaily__label\" [ngClass]=\"this.eat=='0 Times' ? 'childDaily__label--check' : 'normal'\">\n                            0 Times\n                        </ion-label>\n                    </ion-item>\n                    <ion-item class=\"childDaily__radio-item ion-no-padding\" lines=\"none\">\n                        <ion-radio class=\"childDaily__rdo\" value=\"1 Times\"></ion-radio>\n                        <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.eat=='1 Times' ? 'childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                        <ion-label class=\"childDaily__label\" [ngClass]=\"this.eat=='1 Times' ? 'childDaily__label--check' : 'normal'\">\n                            1 Times\n                        </ion-label>\n                    </ion-item>\n                    <ion-item class=\"childDaily__radio-item ion-no-padding\" lines=\"none\">\n                        <ion-radio class=\"childDaily__rdo \" value=\"2 Times\"></ion-radio>\n                        <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.eat=='2 Times' ? 'childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                        <ion-label class=\"childDaily__label\" [ngClass]=\"this.eat=='2 Times' ? 'childDaily__label--check' : 'normal'\">\n                            2 Times\n                        </ion-label>\n                    </ion-item>\n                    <ion-item class=\"childDaily__radio-item ion-no-padding\" lines=\"none\">\n                        <ion-radio class=\"childDaily__rdo\" value=\"3 Times\"></ion-radio>\n                        <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.eat=='3 Times' ? 'childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                        <ion-label class=\"childDaily__label\" [ngClass]=\"this.eat=='3 Times' ? 'childDaily__label--check' : 'normal'\">\n                            3 Times\n                        </ion-label>\n                    </ion-item>\n                </ion-list>\n            </ion-radio-group>\n            <ion-list class=\"childDaily__stick\">\n                <ion-text class=\"childDaily__text\">\n                    “Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book .....”\n                </ion-text>\n                <ion-label class=\"childDaily__assign\">\n                    - Ahmed Mohsen\n                </ion-label>\n            </ion-list>\n        </ion-list>\n        <ion-list class=\"childDaily__list\">\n            <ion-text class=\"childDaily__title\">The menu of the day</ion-text>\n            <ion-list class=\"childDaily__menu-list\">\n                <ion-item class=\"childDaily__menu-item ion-no-padding\" lines=\"none\">\n                    <ion-checkbox class=\"childDaily__rdo\" value=\"Cheese Sandwitch\" (ionChange)=\"setChecked1($event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.check1 ? 'childDaily__selected childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"childDaily__menu-text\" [ngClass]=\"this.check1 ? 'childDaily__menu-text--check' : 'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-sandwitch.png\"></ion-img>\n                        <ion-text>\n                            Cheese Sandwitch\n                        </ion-text>\n                    </ion-list>\n                </ion-item>\n                <ion-item class=\"childDaily__menu-item ion-no-padding\" lines=\"none\">\n                    <ion-checkbox class=\"childDaily__rdo\" value=\"Banana\" (ionChange)=\"setChecked2($event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.check2 ? 'childDaily__selected childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"childDaily__menu-text\" [ngClass]=\"this.check2 ? 'childDaily__menu-text--check' : 'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-banana.png\"></ion-img>\n                        <ion-text>\n                            Banana\n                        </ion-text>\n                    </ion-list>\n                </ion-item>\n                <ion-item class=\"childDaily__menu-item ion-no-padding\" lines=\"none\">\n                    <ion-checkbox class=\"childDaily__rdo\" value=\"Apple\" (ionChange)=\"setChecked3($event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.check3 ? 'childDaily__selected childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"childDaily__menu-text\" [ngClass]=\"this.check3 ? 'childDaily__menu-text--check' : 'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-apple.png\"></ion-img>\n                        <ion-text>\n                            Apple\n                        </ion-text>\n                    </ion-list>\n                </ion-item>\n                <ion-item class=\"childDaily__menu-item ion-no-padding\" lines=\"none\">\n                    <ion-checkbox class=\"childDaily__rdo\" value=\"Mango Juice\" (ionChange)=\"setChecked4($event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon childDaily__selected\" [ngClass]=\"this.check4 ? 'childDaily__selected childDaily__selected--show' : 'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"childDaily__menu-text\" [ngClass]=\"this.check4 ? 'childDaily__menu-text--check' : 'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-mangojuice.png\"></ion-img>\n                        <ion-text>\n                            Mango Juice\n                        </ion-text>\n                    </ion-list>\n                </ion-item>\n            </ion-list>\n            <ion-list class=\"childDaily__stick\">\n                <ion-text class=\"childDaily__text\">\n                    “Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book .....”\n                </ion-text>\n                <ion-label class=\"childDaily__assign childDaily__assign--blue\">\n                    - Ahmed Mohsen\n                </ion-label>\n            </ion-list>\n        </ion-list>\n        <ion-list class=\"childDaily__list\">\n            <ion-text class=\"childDaily__title\">Nap time:</ion-text>\n            <ion-list class=\"childDaily__radio ion-no-padding\">\n                <ion-item class=\"childDaily__input ion-no-padding\" lines=\"none\">\n                    <ion-label position=\"floating\" class=\"label label--blue label--top\">Duration</ion-label>\n                    <ion-select class=\"childDaily__input-text input input--small childDaily__select\" value=\"1\" placeholder=\"Select\">\n                        <ion-select-option value=\"1\" selected>1 Hour</ion-select-option>\n                        <ion-select-option value=\"2\">2 Hour</ion-select-option>\n                        <ion-select-option value=\"2\">3 Hour</ion-select-option>\n                    </ion-select>\n                </ion-item>\n                <ion-item class=\"childDaily__input ion-margin-start\" lines=\"none\">\n                    <ion-label position=\"floating\" class=\"label label--blue label--top\">Time the child slept</ion-label>\n                    <ion-select class=\"childDaily__input-text input input--small childDaily__select\" value=\"2\" placeholder=\"Select\">\n                        <ion-select-option value=\"1\" selected>02:00 PM : 03:00 PM</ion-select-option>\n                        <ion-select-option value=\"2\">03:00 PM : 04:00 PM</ion-select-option>\n                        <ion-select-option value=\"2\">04:00 PM : 05:00 PM</ion-select-option>\n                    </ion-select>\n                </ion-item>\n            </ion-list>\n        </ion-list>\n        <ion-list class=\"childDaily__list\">\n            <ion-text class=\"childDaily__title\">Bowel movement:</ion-text>\n            <ion-list class=\"childDaily__radio childDaily__radio-padding\">\n                <ion-item class=\"childDaily__radio-item childDaily__radio-item-yes ion-no-padding\" lines=\"none\">\n                    <ion-img class=\"icon icon--selected childDaily__selected childDaily__selected--show\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-label class=\"childDaily__label childDaily__label--check childDaily__label-yes\">Yes</ion-label>\n                    <ion-radio class=\"childDaily__rdo\" value=\"yes\"></ion-radio>\n                </ion-item>\n                <ion-item class=\"childDaily__radio-item childDaily__radio-item-yes label--right ion-no-padding\" lines=\"none\">\n                    <ion-label class=\"childDaily__label childDaily__label--check  childDaily__label-yes label--right\">3 Times</ion-label>\n                </ion-item>\n            </ion-list>\n        </ion-list>\n        <ion-list class=\"childDaily__list\">\n            <ion-text class=\"childDaily__title\">Record injuries:</ion-text>\n            <ion-radio-group>\n                <ion-list class=\"childDaily__radio childDaily__radio-padding\">\n                    <ion-item class=\"childDaily__radio-item childDaily__radio-item-yes ion-no-padding\" lines=\"none\">\n                        <ion-img class=\"icon icon--selected childDaily__selected childDaily__selected--show\" src=\"assets/images/icon-selected.png\"></ion-img>\n                        <ion-label class=\"childDaily__label childDaily__label--check childDaily__label-yes\">Yes</ion-label>\n                        <ion-radio class=\"childDaily__rdo\" value=\"yes\"></ion-radio>\n                    </ion-item>\n                    <ion-item class=\"childDaily__input ion-margin-start\" lines=\"none\">\n                        <ion-label position=\"floating\" class=\"label label--blue label--top\">Where</ion-label>\n                        <ion-input class=\"input input--small\" placeholder=\"Write here\" type=\"text\" value=\"Twinky Finger\"></ion-input>\n                        <ion-radio class=\"childDaily__rdo\" value=\"yes\"></ion-radio>\n                    </ion-item>\n                    <ion-item class=\"childDaily__input ion-margin-start\" lines=\"none\">\n                        <ion-label position=\"floating\" class=\"label label--blue label--top\">When</ion-label>\n                        <ion-select class=\"childDaily__input-text input input--small childDaily__select\" value=\"2\" placeholder=\"Select\">\n                            <ion-select-option value=\"1\">10:00 AM</ion-select-option>\n                            <ion-select-option value=\"2\">11:00 AM</ion-select-option>\n                            <ion-select-option value=\"2\">12:00 AM</ion-select-option>\n                        </ion-select>\n\n                    </ion-item>\n                </ion-list>\n            </ion-radio-group>\n        </ion-list>\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/dailyinfomation/dailyinfomation-routing.module.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/dailyinfomation/dailyinfomation-routing.module.ts ***!
    \*******************************************************************/

  /*! exports provided: DailyinfomationPageRoutingModule */

  /***/
  function srcAppDailyinfomationDailyinfomationRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyinfomationPageRoutingModule", function () {
      return DailyinfomationPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _dailyinfomation_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./dailyinfomation.page */
    "./src/app/dailyinfomation/dailyinfomation.page.ts");

    var routes = [{
      path: '',
      component: _dailyinfomation_page__WEBPACK_IMPORTED_MODULE_3__["DailyinfomationPage"]
    }];

    var DailyinfomationPageRoutingModule = function DailyinfomationPageRoutingModule() {
      _classCallCheck(this, DailyinfomationPageRoutingModule);
    };

    DailyinfomationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DailyinfomationPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/dailyinfomation/dailyinfomation.module.ts":
  /*!***********************************************************!*\
    !*** ./src/app/dailyinfomation/dailyinfomation.module.ts ***!
    \***********************************************************/

  /*! exports provided: DailyinfomationPageModule */

  /***/
  function srcAppDailyinfomationDailyinfomationModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyinfomationPageModule", function () {
      return DailyinfomationPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _dailyinfomation_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./dailyinfomation-routing.module */
    "./src/app/dailyinfomation/dailyinfomation-routing.module.ts");
    /* harmony import */


    var _dailyinfomation_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dailyinfomation.page */
    "./src/app/dailyinfomation/dailyinfomation.page.ts");

    var DailyinfomationPageModule = function DailyinfomationPageModule() {
      _classCallCheck(this, DailyinfomationPageModule);
    };

    DailyinfomationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _dailyinfomation_routing_module__WEBPACK_IMPORTED_MODULE_5__["DailyinfomationPageRoutingModule"]],
      declarations: [_dailyinfomation_page__WEBPACK_IMPORTED_MODULE_6__["DailyinfomationPage"]]
    })], DailyinfomationPageModule);
    /***/
  },

  /***/
  "./src/app/dailyinfomation/dailyinfomation.page.scss":
  /*!***********************************************************!*\
    !*** ./src/app/dailyinfomation/dailyinfomation.page.scss ***!
    \***********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppDailyinfomationDailyinfomationPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\n.img {\n  max-width: 50px;\n  width: 100%;\n  display: block;\n  border-radius: 50%;\n}\n\n.childDaily {\n  width: 100%;\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  justify-content: center;\n  padding: 0 10px;\n  margin-bottom: 50px;\n}\n\n.childDaily__list {\n  width: 100%;\n  margin-top: 10px;\n  display: flex;\n  flex-direction: column;\n}\n\n.childDaily__title {\n  color: #4f4f4f;\n  font-weight: 600;\n  margin-bottom: 10px;\n}\n\n.childDaily__radio {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 10px 0 0;\n  margin: 5px 0;\n  height: 68px;\n}\n\n.childDaily__radio-padding {\n  padding-top: 10px;\n}\n\n.childDaily__radio--big {\n  height: 100%;\n}\n\n.childDaily__radio-item {\n  width: 23%;\n  position: relative;\n  --inner-padding-end: 0;\n  overflow: visible;\n}\n\n.childDaily__radio-item::part(native) {\n  height: 100%;\n}\n\n.childDaily__radio-item-yes {\n  height: 55px;\n  margin-right: 10px;\n}\n\n.childDaily__label {\n  width: 100%;\n  height: 48px;\n  line-height: 48px;\n  margin: 0;\n  font-size: inherit;\n  color: #9c9c9c !important;\n  font-weight: 400;\n  text-align: center;\n  position: absolute;\n  border: 1px solid #d7d7d7;\n  border-radius: 10px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.childDaily__label--check {\n  border: 1px solid #187bad;\n}\n\n.childDaily__label-yes {\n  height: 55px;\n  line-height: 56px;\n}\n\n.childDaily__select {\n  margin-bottom: 20px;\n  padding-right: 0;\n}\n\n.childDaily__select::part(icon) {\n  opacity: 0;\n}\n\n.childDaily__selected {\n  width: 30px;\n  position: absolute;\n  z-index: 99;\n  top: -10px;\n  right: -10px;\n  display: none;\n}\n\n.childDaily__selected--show {\n  display: block;\n}\n\n.childDaily__stick {\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: flex-start;\n  width: 100%;\n  font-size: 14px;\n  color: #a3a3a3;\n  padding: 10px;\n  background: #f6f6f6;\n  border: 1px solid #d7d7d7;\n  border-radius: 5px;\n  margin: 10px 0;\n}\n\n.childDaily__assign {\n  color: #323131;\n  font-weight: 600;\n  margin-top: 10px;\n}\n\n.childDaily__assign--blue {\n  color: #187bad;\n}\n\n.childDaily__rdo {\n  opacity: 0;\n}\n\n.childDaily__comment {\n  font-size: 14px;\n  color: #a3a3a3;\n  border: 1px solid #d7d7d7;\n  height: 80px;\n  padding: 5px;\n  margin: 10px 0;\n  border-radius: 10px;\n}\n\n.childDaily__comment .native-textarea {\n  height: 130px;\n}\n\n.childDaily__radio-height {\n  height: 95px;\n  padding: 5px;\n  box-sizing: border-box;\n}\n\n.childDaily__list-day {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  margin: 10px 0;\n}\n\n.childDaily__input {\n  border: 1px solid #d7d7d7 !important;\n  border-radius: 5px;\n  color: #8b8b8b;\n  font-size: 14px;\n  height: 55px;\n}\n\n.childDaily__input-width {\n  width: 40%;\n  --inner-padding-end: 0;\n}\n\n.childDaily__input-text {\n  font-size: 13px;\n  font-weight: 600;\n  color: #8b8b8b;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.childDaily__menu-list {\n  display: flex;\n  width: 100%;\n  height: 100%;\n  margin: 5px 0;\n  padding: 10px 10px 10px 0;\n  justify-content: space-between;\n  align-items: center;\n  position: relative;\n}\n\n.childDaily__menu-item {\n  width: 23%;\n  height: 95px;\n  --inner-padding-end: 0;\n  overflow: visible;\n  position: relative;\n  --min-height: 100% !important;\n}\n\n.childDaily__menu-item::part(native) {\n  height: 100%;\n}\n\n.childDaily__menu-item .item-native {\n  --height: 100% !important;\n}\n\n.childDaily__menu-text {\n  width: 100%;\n  height: 95px;\n  display: flex;\n  flex-direction: column;\n  justify-content: center;\n  align-items: center;\n  background: unset;\n  text-align: center;\n  position: absolute;\n  color: #565656;\n  font-size: 13px;\n  font-weight: 600;\n  border: 1px solid #d7d7d7;\n  border-radius: 10px;\n}\n\n.childDaily__menu-text--check {\n  border: 1px solid #187bad;\n}\n\n.img--fruit {\n  max-width: 45px;\n  margin-bottom: 5px;\n}\n\n.list-day__item {\n  width: 45%;\n  padding: 10px;\n  border: 1px solid #d7d7d7;\n  border-radius: 5px;\n  color: #4f4f4f;\n  font-size: 14px;\n}\n\n.label--blue {\n  color: #187bad !important;\n  font-weight: 600;\n}\n\n.label--right {\n  margin-right: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGFpbHlpbmZvbWF0aW9uL0Q6XFx0YXNrXFwyMDIwMDcwN1xcd29ya1xcY2hpbGRfYXBwL3NyY1xcYXBwXFxkYWlseWluZm9tYXRpb25cXGRhaWx5aW5mb21hdGlvbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2RhaWx5aW5mb21hdGlvbi9kYWlseWluZm9tYXRpb24ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7RUFDQSxzQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsNERBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQ0NKOztBREdBO0VBQ0ksV0FBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsbUJBQUE7QUNBSjs7QURDSTtFQUNJLFdBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQ0NSOztBRENJO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUNDUjs7QURDSTtFQUNJLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7QUNDUjs7QURBUTtFQUNJLGlCQUFBO0FDRVo7O0FEQVE7RUFDSSxZQUFBO0FDRVo7O0FEQ0k7RUFDSSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGlCQUFBO0FDQ1I7O0FEQVE7RUFDSSxZQUFBO0FDRVo7O0FEQVE7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7QUNFWjs7QURTSTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxTQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7RUFDQSw0REFBQTtBQ1BSOztBRFFRO0VBQ0kseUJBQUE7QUNOWjs7QURRUTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtBQ05aOztBRFNJO0VBQ0ksbUJBQUE7RUFDQSxnQkFBQTtBQ1BSOztBRFFRO0VBQ0ksVUFBQTtBQ05aOztBRFNJO0VBQ0ksV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtBQ1BSOztBRFFRO0VBQ0ksY0FBQTtBQ05aOztBRFNJO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FDUFI7O0FEU0k7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtBQ1BSOztBRFFRO0VBQ0ksY0FBQTtBQ05aOztBRGVJO0VBQ0ksVUFBQTtBQ2JSOztBRGdCSTtFQUNJLGVBQUE7RUFDQSxjQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQ2RSOztBRGVRO0VBQ0ksYUFBQTtBQ2JaOztBRGdCSTtFQUNJLFlBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUNkUjs7QURnQkk7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0FDZFI7O0FEZ0JJO0VBQ0ksb0NBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ2RSOztBRGdCUTtFQUNJLFVBQUE7RUFDQSxzQkFBQTtBQ2RaOztBRGdCUTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSw0REFBQTtBQ2RaOztBRGlCSTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ2ZSOztBRGlCSTtFQUNJLFVBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsNkJBQUE7QUNmUjs7QURnQlE7RUFDSSxZQUFBO0FDZFo7O0FEZ0JRO0VBQ0kseUJBQUE7QUNkWjs7QURpQkk7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQ2ZSOztBRGdCUTtFQUNJLHlCQUFBO0FDZFo7O0FEbUJBO0VBQ0ksZUFBQTtFQUNBLGtCQUFBO0FDaEJKOztBRG1CQTtFQUNJLFVBQUE7RUFDQSxhQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDaEJKOztBRG1CQTtFQUNJLHlCQUFBO0VBQ0EsZ0JBQUE7QUNoQko7O0FEbUJBO0VBQ0ksa0JBQUE7QUNoQkoiLCJmaWxlIjoic3JjL2FwcC9kYWlseWluZm9tYXRpb24vZGFpbHlpbmZvbWF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmcnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuXHJcbmlvbi10aXRsZSB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxufVxyXG5cclxuLmltZyB7XHJcbiAgICBtYXgtd2lkdGg6IDUwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcblxyXG4vLyBjaGlsZCBkYWlseSDDrG5vIGNlbnRlclxyXG4uY2hpbGREYWlseSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDAgMTBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbiAgICAmX19saXN0IHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIH1cclxuICAgICZfX3RpdGxlIHtcclxuICAgICAgICBjb2xvcjogIzRmNGY0ZjtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICB9XHJcbiAgICAmX19yYWRpbyB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwYWRkaW5nOiAwIDEwcHggMCAwO1xyXG4gICAgICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICAgICAgaGVpZ2h0OiA2OHB4O1xyXG4gICAgICAgICYtcGFkZGluZyB7XHJcbiAgICAgICAgICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLS1iaWcge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgJl9fcmFkaW8taXRlbSB7XHJcbiAgICAgICAgd2lkdGg6IDIzJTtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICBvdmVyZmxvdzogdmlzaWJsZTtcclxuICAgICAgICAmOjpwYXJ0KG5hdGl2ZSkge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYteWVzIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiA1NXB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLy8gJl9faXRlbVJkbyB7XHJcbiAgICAvLyAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICAvLyAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAvLyAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAvLyAgICY6OnBhcnQobmF0aXZlKSB7XHJcbiAgICAvLyAgICAgcGFkZGluZzogMDtcclxuICAgIC8vICAgfVxyXG4gICAgLy8gfVxyXG4gICAgJl9fbGFiZWwge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGhlaWdodDogNDhweDtcclxuICAgICAgICBsaW5lLWhlaWdodDogNDhweDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgZm9udC1zaXplOiBpbmhlcml0O1xyXG4gICAgICAgIGNvbG9yOiAjOWM5YzljICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICAmLS1jaGVjayB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMxODdiYWQ7XHJcbiAgICAgICAgfVxyXG4gICAgICAgICYteWVzIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiA1NXB4O1xyXG4gICAgICAgICAgICBsaW5lLWhlaWdodDogNTZweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAmX19zZWxlY3Qge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbiAgICAgICAgcGFkZGluZy1yaWdodDogMDtcclxuICAgICAgICAmOjpwYXJ0KGljb24pIHtcclxuICAgICAgICAgICAgb3BhY2l0eTogMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAmX19zZWxlY3RlZCB7XHJcbiAgICAgICAgd2lkdGg6IDMwcHg7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHotaW5kZXg6IDk5O1xyXG4gICAgICAgIHRvcDogLTEwcHg7XHJcbiAgICAgICAgcmlnaHQ6IC0xMHB4O1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgICAgJi0tc2hvdyB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgICZfX3N0aWNrIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjYTNhM2EzO1xyXG4gICAgICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2Y2ZjZmNjtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICBtYXJnaW46IDEwcHggMDtcclxuICAgIH1cclxuICAgICZfX2Fzc2lnbiB7XHJcbiAgICAgICAgY29sb3I6ICMzMjMxMzE7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICAgICYtLWJsdWUge1xyXG4gICAgICAgICAgICBjb2xvcjogIzE4N2JhZDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAvLyAmX19sYWJlbDIge1xyXG4gICAgLy8gICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAvLyAgIGNvbG9yOiAjOWM5YzljO1xyXG4gICAgLy8gICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgLy8gICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAvLyB9XHJcbiAgICAmX19yZG8ge1xyXG4gICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgLy8gcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgfVxyXG4gICAgJl9fY29tbWVudCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIGNvbG9yOiAjYTNhM2EzO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICAgICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDVweDtcclxuICAgICAgICBtYXJnaW46IDEwcHggMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICYgLm5hdGl2ZS10ZXh0YXJlYSB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTMwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgJl9fcmFkaW8taGVpZ2h0IHtcclxuICAgICAgICBoZWlnaHQ6IDk1cHg7XHJcbiAgICAgICAgcGFkZGluZzogNXB4O1xyXG4gICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICB9XHJcbiAgICAmX19saXN0LWRheSB7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW46IDEwcHggMDtcclxuICAgIH1cclxuICAgICZfX2lucHV0IHtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIGNvbG9yOiAjOGI4YjhiO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBoZWlnaHQ6IDU1cHg7XHJcbiAgICAgICAgLy8gLS1pbm5lci1wYWRkaW5nLXN0YXJ0OiAyMHB4O1xyXG4gICAgICAgICYtd2lkdGgge1xyXG4gICAgICAgICAgICB3aWR0aDogNDAlO1xyXG4gICAgICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgIH1cclxuICAgICAgICAmLXRleHQge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjOGI4YjhiO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAmX19tZW51LWxpc3Qge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIG1hcmdpbjogNXB4IDA7XHJcbiAgICAgICAgcGFkZGluZzogMTBweCAxMHB4IDEwcHggMDtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB9XHJcbiAgICAmX19tZW51LWl0ZW0ge1xyXG4gICAgICAgIHdpZHRoOiAyMyU7XHJcbiAgICAgICAgaGVpZ2h0OiA5NXB4O1xyXG4gICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgb3ZlcmZsb3c6IHZpc2libGU7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIC0tbWluLWhlaWdodDogMTAwJSAhaW1wb3J0YW50O1xyXG4gICAgICAgICY6OnBhcnQobmF0aXZlKSB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICB9XHJcbiAgICAgICAgLml0ZW0tbmF0aXZlIHtcclxuICAgICAgICAgICAgLS1oZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAmX19tZW51LXRleHQge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGhlaWdodDogOTVweDtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB1bnNldDtcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGNvbG9yOiAjNTY1NjU2O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAmLS1jaGVjayB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICMxODdiYWQ7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uaW1nLS1mcnVpdCB7XHJcbiAgICBtYXgtd2lkdGg6IDQ1cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA1cHg7XHJcbn1cclxuXHJcbi5saXN0LWRheV9faXRlbSB7XHJcbiAgICB3aWR0aDogNDUlO1xyXG4gICAgcGFkZGluZzogMTBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBjb2xvcjogIzRmNGY0ZjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmxhYmVsLS1ibHVlIHtcclxuICAgIGNvbG9yOiAjMTg3YmFkICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcblxyXG4ubGFiZWwtLXJpZ2h0IHtcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxufSIsImlvbi1oZWFkZXIge1xuICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmdcIik7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG5cbmlvbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbi5pbWcge1xuICBtYXgtd2lkdGg6IDUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBibG9jaztcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuXG4uY2hpbGREYWlseSB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIHBhZGRpbmc6IDAgMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogNTBweDtcbn1cbi5jaGlsZERhaWx5X19saXN0IHtcbiAgd2lkdGg6IDEwMCU7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG59XG4uY2hpbGREYWlseV9fdGl0bGUge1xuICBjb2xvcjogIzRmNGY0ZjtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cbi5jaGlsZERhaWx5X19yYWRpbyB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHBhZGRpbmc6IDAgMTBweCAwIDA7XG4gIG1hcmdpbjogNXB4IDA7XG4gIGhlaWdodDogNjhweDtcbn1cbi5jaGlsZERhaWx5X19yYWRpby1wYWRkaW5nIHtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG59XG4uY2hpbGREYWlseV9fcmFkaW8tLWJpZyB7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5jaGlsZERhaWx5X19yYWRpby1pdGVtIHtcbiAgd2lkdGg6IDIzJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbn1cbi5jaGlsZERhaWx5X19yYWRpby1pdGVtOjpwYXJ0KG5hdGl2ZSkge1xuICBoZWlnaHQ6IDEwMCU7XG59XG4uY2hpbGREYWlseV9fcmFkaW8taXRlbS15ZXMge1xuICBoZWlnaHQ6IDU1cHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cbi5jaGlsZERhaWx5X19sYWJlbCB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDQ4cHg7XG4gIGxpbmUtaGVpZ2h0OiA0OHB4O1xuICBtYXJnaW46IDA7XG4gIGZvbnQtc2l6ZTogaW5oZXJpdDtcbiAgY29sb3I6ICM5YzljOWMgIWltcG9ydGFudDtcbiAgZm9udC13ZWlnaHQ6IDQwMDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuLmNoaWxkRGFpbHlfX2xhYmVsLS1jaGVjayB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICMxODdiYWQ7XG59XG4uY2hpbGREYWlseV9fbGFiZWwteWVzIHtcbiAgaGVpZ2h0OiA1NXB4O1xuICBsaW5lLWhlaWdodDogNTZweDtcbn1cbi5jaGlsZERhaWx5X19zZWxlY3Qge1xuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xuICBwYWRkaW5nLXJpZ2h0OiAwO1xufVxuLmNoaWxkRGFpbHlfX3NlbGVjdDo6cGFydChpY29uKSB7XG4gIG9wYWNpdHk6IDA7XG59XG4uY2hpbGREYWlseV9fc2VsZWN0ZWQge1xuICB3aWR0aDogMzBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB6LWluZGV4OiA5OTtcbiAgdG9wOiAtMTBweDtcbiAgcmlnaHQ6IC0xMHB4O1xuICBkaXNwbGF5OiBub25lO1xufVxuLmNoaWxkRGFpbHlfX3NlbGVjdGVkLS1zaG93IHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4uY2hpbGREYWlseV9fc3RpY2sge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIGNvbG9yOiAjYTNhM2EzO1xuICBwYWRkaW5nOiAxMHB4O1xuICBiYWNrZ3JvdW5kOiAjZjZmNmY2O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIG1hcmdpbjogMTBweCAwO1xufVxuLmNoaWxkRGFpbHlfX2Fzc2lnbiB7XG4gIGNvbG9yOiAjMzIzMTMxO1xuICBmb250LXdlaWdodDogNjAwO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xufVxuLmNoaWxkRGFpbHlfX2Fzc2lnbi0tYmx1ZSB7XG4gIGNvbG9yOiAjMTg3YmFkO1xufVxuLmNoaWxkRGFpbHlfX3JkbyB7XG4gIG9wYWNpdHk6IDA7XG59XG4uY2hpbGREYWlseV9fY29tbWVudCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICNhM2EzYTM7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XG4gIGhlaWdodDogODBweDtcbiAgcGFkZGluZzogNXB4O1xuICBtYXJnaW46IDEwcHggMDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbi5jaGlsZERhaWx5X19jb21tZW50IC5uYXRpdmUtdGV4dGFyZWEge1xuICBoZWlnaHQ6IDEzMHB4O1xufVxuLmNoaWxkRGFpbHlfX3JhZGlvLWhlaWdodCB7XG4gIGhlaWdodDogOTVweDtcbiAgcGFkZGluZzogNXB4O1xuICBib3gtc2l6aW5nOiBib3JkZXItYm94O1xufVxuLmNoaWxkRGFpbHlfX2xpc3QtZGF5IHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgbWFyZ2luOiAxMHB4IDA7XG59XG4uY2hpbGREYWlseV9faW5wdXQge1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3ICFpbXBvcnRhbnQ7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgY29sb3I6ICM4YjhiOGI7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgaGVpZ2h0OiA1NXB4O1xufVxuLmNoaWxkRGFpbHlfX2lucHV0LXdpZHRoIHtcbiAgd2lkdGg6IDQwJTtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcbn1cbi5jaGlsZERhaWx5X19pbnB1dC10ZXh0IHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBjb2xvcjogIzhiOGI4YjtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG4uY2hpbGREYWlseV9fbWVudS1saXN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgbWFyZ2luOiA1cHggMDtcbiAgcGFkZGluZzogMTBweCAxMHB4IDEwcHggMDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4uY2hpbGREYWlseV9fbWVudS1pdGVtIHtcbiAgd2lkdGg6IDIzJTtcbiAgaGVpZ2h0OiA5NXB4O1xuICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xuICBvdmVyZmxvdzogdmlzaWJsZTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICAtLW1pbi1oZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbn1cbi5jaGlsZERhaWx5X19tZW51LWl0ZW06OnBhcnQobmF0aXZlKSB7XG4gIGhlaWdodDogMTAwJTtcbn1cbi5jaGlsZERhaWx5X19tZW51LWl0ZW0gLml0ZW0tbmF0aXZlIHtcbiAgLS1oZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcbn1cbi5jaGlsZERhaWx5X19tZW51LXRleHQge1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiA5NXB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgYmFja2dyb3VuZDogdW5zZXQ7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBjb2xvcjogIzU2NTY1NjtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LXdlaWdodDogNjAwO1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuLmNoaWxkRGFpbHlfX21lbnUtdGV4dC0tY2hlY2sge1xuICBib3JkZXI6IDFweCBzb2xpZCAjMTg3YmFkO1xufVxuXG4uaW1nLS1mcnVpdCB7XG4gIG1heC13aWR0aDogNDVweDtcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xufVxuXG4ubGlzdC1kYXlfX2l0ZW0ge1xuICB3aWR0aDogNDUlO1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZDdkN2Q3O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIGNvbG9yOiAjNGY0ZjRmO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5sYWJlbC0tYmx1ZSB7XG4gIGNvbG9yOiAjMTg3YmFkICFpbXBvcnRhbnQ7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG59XG5cbi5sYWJlbC0tcmlnaHQge1xuICBtYXJnaW4tcmlnaHQ6IGF1dG87XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/dailyinfomation/dailyinfomation.page.ts":
  /*!*********************************************************!*\
    !*** ./src/app/dailyinfomation/dailyinfomation.page.ts ***!
    \*********************************************************/

  /*! exports provided: DailyinfomationPage */

  /***/
  function srcAppDailyinfomationDailyinfomationPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyinfomationPage", function () {
      return DailyinfomationPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var DailyinfomationPage = /*#__PURE__*/function () {
      function DailyinfomationPage(platform, navCtrl) {
        _classCallCheck(this, DailyinfomationPage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.eat = '0 Times';
        this.check1 = true;
        this.check2 = true;
        this.check3 = true;
        this.check4 = true;
        this.pt_active = false;
      }

      _createClass(DailyinfomationPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }, {
        key: "getData",
        value: function getData(p) {
          this.eat = p;
        }
      }, {
        key: "setChecked1",
        value: function setChecked1(p) {
          this.check1 = p;
        }
      }, {
        key: "setChecked2",
        value: function setChecked2(p2) {
          this.check2 = p2;
        }
      }, {
        key: "setChecked3",
        value: function setChecked3(p3) {
          this.check3 = p3;
        }
      }, {
        key: "setChecked4",
        value: function setChecked4(p4) {
          this.check4 = p4;
        }
      }]);

      return DailyinfomationPage;
    }();

    DailyinfomationPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    DailyinfomationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-dailyinfomation',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./dailyinfomation.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dailyinfomation/dailyinfomation.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./dailyinfomation.page.scss */
      "./src/app/dailyinfomation/dailyinfomation.page.scss"))["default"]]
    })], DailyinfomationPage);
    /***/
  }
}]);
//# sourceMappingURL=dailyinfomation-dailyinfomation-module-es5.js.map