function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["school-school-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/school/school.page.html":
  /*!*******************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/school/school.page.html ***!
    \*******************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSchoolSchoolPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n        <ion-title>School Documents</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-icon name=\"search\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-list>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">\n                            School Calendar\n                            <ion-label class=\"brage\">New</ion-label>\n                        </ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">\n                            Routine of the day\n                        </ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">\n                            School menu\n                        </ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">\n                            School supplies to buy\n                            <ion-label class=\"brage\">New</ion-label>\n                        </ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">Rule book</ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n        <ion-item>\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"10\">\n                        <ion-text class=\"school_text\">Our documents</ion-text>\n                    </ion-col>\n                    <ion-col class=\"ion-text-end\" size=\"2\">\n                        <img src=\"../../assets/images/icon-download.png\" alt=\"\">\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/school/school-routing.module.ts":
  /*!*************************************************!*\
    !*** ./src/app/school/school-routing.module.ts ***!
    \*************************************************/

  /*! exports provided: SchoolPageRoutingModule */

  /***/
  function srcAppSchoolSchoolRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchoolPageRoutingModule", function () {
      return SchoolPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _school_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./school.page */
    "./src/app/school/school.page.ts");

    var routes = [{
      path: '',
      component: _school_page__WEBPACK_IMPORTED_MODULE_3__["SchoolPage"]
    }];

    var SchoolPageRoutingModule = function SchoolPageRoutingModule() {
      _classCallCheck(this, SchoolPageRoutingModule);
    };

    SchoolPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SchoolPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/school/school.module.ts":
  /*!*****************************************!*\
    !*** ./src/app/school/school.module.ts ***!
    \*****************************************/

  /*! exports provided: SchoolPageModule */

  /***/
  function srcAppSchoolSchoolModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchoolPageModule", function () {
      return SchoolPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _school_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./school-routing.module */
    "./src/app/school/school-routing.module.ts");
    /* harmony import */


    var _school_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./school.page */
    "./src/app/school/school.page.ts");

    var SchoolPageModule = function SchoolPageModule() {
      _classCallCheck(this, SchoolPageModule);
    };

    SchoolPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _school_routing_module__WEBPACK_IMPORTED_MODULE_5__["SchoolPageRoutingModule"]],
      declarations: [_school_page__WEBPACK_IMPORTED_MODULE_6__["SchoolPage"]]
    })], SchoolPageModule);
    /***/
  },

  /***/
  "./src/app/school/school.page.scss":
  /*!*****************************************!*\
    !*** ./src/app/school/school.page.scss ***!
    \*****************************************/

  /*! exports provided: default */

  /***/
  function srcAppSchoolSchoolPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\nion-item {\n  --border-width: 0px;\n  margin-right: 15px;\n  --inner-padding-end: 0px;\n}\n\nion-grid .school_text {\n  color: #4c4c4c;\n  font-weight: 600;\n  font-size: 16px;\n  display: flex;\n  padding-top: 5px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-grid .brage {\n  background: #f33232;\n  color: white;\n  margin-left: 10px;\n  border-radius: 5px;\n  padding: 0px 10px;\n  font-weight: 400;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-list {\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\nion-col img {\n  max-width: 30px;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2Nob29sL0Q6XFx0YXNrXFwyMDIwMDcwN1xcd29ya1xcY2hpbGRfYXBwL3NyY1xcYXBwXFxzY2hvb2xcXHNjaG9vbC5wYWdlLnNjc3MiLCJzcmMvYXBwL3NjaG9vbC9zY2hvb2wucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksc0NBQUE7RUFDQSxzQkFBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsNERBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FDQ0o7O0FERUE7RUFDSSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esd0JBQUE7QUNDSjs7QURHSTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7RUFDQSw0REFBQTtBQ0FSOztBREVJO0VBQ0ksbUJBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw0REFBQTtBQ0FSOztBRElBO0VBQ0ksaUJBQUE7RUFDQSxvQkFBQTtBQ0RKOztBRElBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7QUNESiIsImZpbGUiOiJzcmMvYXBwL3NjaG9vbC9zY2hvb2wucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZycpO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuaW9uLXRpdGxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1idXR0b25zIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICAtLWJvcmRlci13aWR0aDogMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xyXG59XHJcblxyXG5pb24tZ3JpZCB7XHJcbiAgICAuc2Nob29sX3RleHQge1xyXG4gICAgICAgIGNvbG9yOiAjNGM0YzRjO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDVweDtcclxuICAgICAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgIH1cclxuICAgIC5icmFnZSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2YzMzIzMjtcclxuICAgICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgIHBhZGRpbmc6IDBweCAxMHB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbn1cclxuXHJcbmlvbi1jb2wgaW1nIHtcclxuICAgIG1heC13aWR0aDogMzBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59IiwiaW9uLWhlYWRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuaW9uLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1idXR0b25zIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJvcmRlci13aWR0aDogMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDE1cHg7XG4gIC0taW5uZXItcGFkZGluZy1lbmQ6IDBweDtcbn1cblxuaW9uLWdyaWQgLnNjaG9vbF90ZXh0IHtcbiAgY29sb3I6ICM0YzRjNGM7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZGlzcGxheTogZmxleDtcbiAgcGFkZGluZy10b3A6IDVweDtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG5pb24tZ3JpZCAuYnJhZ2Uge1xuICBiYWNrZ3JvdW5kOiAjZjMzMjMyO1xuICBjb2xvcjogd2hpdGU7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBhZGRpbmc6IDBweCAxMHB4O1xuICBmb250LXdlaWdodDogNDAwO1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuaW9uLWxpc3Qge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbmlvbi1jb2wgaW1nIHtcbiAgbWF4LXdpZHRoOiAzMHB4O1xuICB3aWR0aDogMTAwJTtcbn0iXX0= */";
    /***/
  },

  /***/
  "./src/app/school/school.page.ts":
  /*!***************************************!*\
    !*** ./src/app/school/school.page.ts ***!
    \***************************************/

  /*! exports provided: SchoolPage */

  /***/
  function srcAppSchoolSchoolPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SchoolPage", function () {
      return SchoolPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var SchoolPage = /*#__PURE__*/function () {
      function SchoolPage(platform, navCtrl) {
        _classCallCheck(this, SchoolPage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.pt_active = false;
      }

      _createClass(SchoolPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }]);

      return SchoolPage;
    }();

    SchoolPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    SchoolPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-school',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./school.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/school/school.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./school.page.scss */
      "./src/app/school/school.page.scss"))["default"]]
    })], SchoolPage);
    /***/
  }
}]);
//# sourceMappingURL=school-school-module-es5.js.map