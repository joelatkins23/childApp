(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["appointment-appointment-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/appointment/appointment.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/appointment/appointment.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n        <ion-title>Appointment Center</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-icon name=\"search\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-list>\n        <ion-item (click)=\"openModal()\">\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"8\">\n                        <ion-label class=\"appointment_reminder\">Appointment reminder</ion-label>\n                        <ion-label class=\"appointment_date\">Friday: at 4 pm</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                        <ion-label class=\"appointment_status ion-text-end st_pending\">Pending</ion-label>\n                        <ion-label class=\"appointment_date ion-text-end\">2 day later</ion-label>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n         <ion-item (click)=\"openModal()\">\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"8\">\n                        <ion-label class=\"appointment_reminder\">Appointment reminder</ion-label>\n                        <ion-label class=\"appointment_date\">Wednesday</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                        <ion-label class=\"appointment_status ion-text-end st_close\">Close</ion-label>\n                        <ion-label class=\"appointment_date ion-text-end\">2 day later</ion-label>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n         <ion-item (click)=\"openModal()\">\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"8\">\n                        <ion-label class=\"appointment_reminder\">Appointment reminder</ion-label>\n                        <ion-label class=\"appointment_date\">Wednesday</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                        <ion-label class=\"appointment_status ion-text-end st_close\">Close</ion-label>\n                        <ion-label class=\"appointment_date ion-text-end\">2 day later</ion-label>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n         <ion-item (click)=\"openModal()\">\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"8\">\n                        <ion-label class=\"appointment_reminder\">Appointment reminder</ion-label>\n                        <ion-label class=\"appointment_date\">Wednesday</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                        <ion-label class=\"appointment_status ion-text-end st_close\">Close</ion-label>\n                        <ion-label class=\"appointment_date ion-text-end\">2 day later</ion-label>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n         <ion-item (click)=\"openModal()\">\n            <ion-grid>\n                <ion-row>\n                    <ion-col size=\"8\">\n                        <ion-label class=\"appointment_reminder\">Appointment reminder</ion-label>\n                        <ion-label class=\"appointment_date\">Wednesday</ion-label>\n                    </ion-col>\n                    <ion-col size=\"4\">\n                        <ion-label class=\"appointment_status ion-text-end st_close\">Close</ion-label>\n                        <ion-label class=\"appointment_date ion-text-end\">2 day later</ion-label>\n                    </ion-col>\n                </ion-row>\n            </ion-grid>\n        </ion-item>\n    </ion-list>\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/modal/modal.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/modal/modal.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar>\n        <ion-title>Appointment reminder</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-icon class=\"icon_close\" (click)=\"close()\" name=\"close\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n    <ion-list>\n        <ion-list class=\"modal_item\">\n            <ion-list class=\"modal_content\">\n                <ion-label class=\"item_title\">Appointment reminder</ion-label>\n                <ion-list>\n                    <img class=\"clock_img\" src=\"../../assets/images/icon-clock.png\" alt=\"\">\n                    <ion-label class=\"item_clock\">Friday: at 4 pm</ion-label>\n                </ion-list>\n            </ion-list>\n            <ion-button class=\"btn-modal\" expand=\"full\">Booked</ion-button>\n        </ion-list>\n        <ion-list class=\"modal_item\">\n            <ion-list class=\"modal_content\">\n                <ion-label class=\"item_title\">Appointment reminder</ion-label>\n                <ion-list>\n                    <img class=\"clock_img\" src=\"../../assets/images/icon-clock.png\" alt=\"\">\n                    <ion-label class=\"item_clock\">Friday: at 4 pm</ion-label>\n                </ion-list>\n            </ion-list>\n            <ion-button class=\"btn-modal disable\" expand=\"full\">Booked</ion-button>\n        </ion-list>\n        <ion-list class=\"modal_item\">\n            <ion-list class=\"modal_content\">\n                <ion-label class=\"item_title\">Appointment reminder</ion-label>\n                <ion-list>\n                    <img class=\"clock_img\" src=\"../../assets/images/icon-clock.png\" alt=\"\">\n                    <ion-label class=\"item_clock\">Friday: at 4 pm</ion-label>\n                </ion-list>\n            </ion-list>\n            <ion-button class=\"btn-modal disable\" expand=\"full\">Booked</ion-button>\n        </ion-list>\n        <ion-list class=\"modal_item_list\">\n            <ion-list class=\"modal_content\">\n                <ion-label class=\"item_title\">Appointment reminder</ion-label>\n                <ion-list>\n                    <img class=\"clock_img\" src=\"../../assets/images/icon-clock.png\" alt=\"\">\n                    <ion-label class=\"item_clock\">Friday: at 4 pm</ion-label>\n                </ion-list>\n            </ion-list>\n            <ion-button class=\"btn-modal disable\" expand=\"full\">Booked</ion-button>\n        </ion-list>\n    </ion-list>\n    <ion-list class=\"modal_submit\">\n        <ion-button class=\"btn-modal-cofirm\" expand=\"full\">Cofirm</ion-button>\n    </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/appointment/appointment-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/appointment/appointment-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: AppointmentPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentPageRoutingModule", function() { return AppointmentPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _appointment_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./appointment.page */ "./src/app/appointment/appointment.page.ts");




const routes = [
    {
        path: '',
        component: _appointment_page__WEBPACK_IMPORTED_MODULE_3__["AppointmentPage"]
    }
];
let AppointmentPageRoutingModule = class AppointmentPageRoutingModule {
};
AppointmentPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AppointmentPageRoutingModule);



/***/ }),

/***/ "./src/app/appointment/appointment.module.ts":
/*!***************************************************!*\
  !*** ./src/app/appointment/appointment.module.ts ***!
  \***************************************************/
/*! exports provided: AppointmentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentPageModule", function() { return AppointmentPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _appointment_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./appointment-routing.module */ "./src/app/appointment/appointment-routing.module.ts");
/* harmony import */ var _appointment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./appointment.page */ "./src/app/appointment/appointment.page.ts");







let AppointmentPageModule = class AppointmentPageModule {
};
AppointmentPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _appointment_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppointmentPageRoutingModule"]
        ],
        declarations: [_appointment_page__WEBPACK_IMPORTED_MODULE_6__["AppointmentPage"]]
    })
], AppointmentPageModule);



/***/ }),

/***/ "./src/app/appointment/appointment.page.scss":
/*!***************************************************!*\
  !*** ./src/app/appointment/appointment.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\nion-item {\n  margin-right: 15px;\n  --inner-padding-end: 0px;\n}\n\nion-grid .appointment_reminder {\n  font-size: 15px;\n  font-weight: 500;\n  color: #4c4c4c;\n}\n\nion-grid .appointment_date {\n  color: #929292;\n  font-size: 14px;\n}\n\nion-grid .appointment_status {\n  font-size: 16px;\n  font-weight: 500;\n}\n\nion-list {\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.st_pending {\n  color: #ff9c00;\n}\n\n.st_close {\n  color: #e30000;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwb2ludG1lbnQvRDpcXHRhc2tcXDIwMjAwNzA3XFx3b3JrXFxjaGlsZF9hcHAvc3JjXFxhcHBcXGFwcG9pbnRtZW50XFxhcHBvaW50bWVudC5wYWdlLnNjc3MiLCJzcmMvYXBwL2FwcG9pbnRtZW50L2FwcG9pbnRtZW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHNDQUFBO0VBQ0Esc0JBQUE7QUNDSjs7QURFQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLDREQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSx3QkFBQTtBQ0NKOztBREdJO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0FSOztBREVJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUNBUjs7QURFSTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ0FSOztBRElBO0VBQ0ksaUJBQUE7RUFDQSxvQkFBQTtBQ0RKOztBRElBO0VBQ0ksY0FBQTtBQ0RKOztBRElBO0VBQ0ksY0FBQTtBQ0RKIiwiZmlsZSI6InNyYy9hcHAvYXBwb2ludG1lbnQvYXBwb2ludG1lbnQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZycpO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuaW9uLXRpdGxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1idXR0b25zIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbn1cclxuXHJcbmlvbi1ncmlkIHtcclxuICAgIC5hcHBvaW50bWVudF9yZW1pbmRlciB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICAgICAgY29sb3I6ICM0YzRjNGM7XHJcbiAgICB9XHJcbiAgICAuYXBwb2ludG1lbnRfZGF0ZSB7XHJcbiAgICAgICAgY29sb3I6ICM5MjkyOTI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgfVxyXG4gICAgLmFwcG9pbnRtZW50X3N0YXR1cyB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbn1cclxuXHJcbi5zdF9wZW5kaW5nIHtcclxuICAgIGNvbG9yOiAjZmY5YzAwO1xyXG59XHJcblxyXG4uc3RfY2xvc2Uge1xyXG4gICAgY29sb3I6ICNlMzAwMDA7XHJcbn0iLCJpb24taGVhZGVyIHtcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy1oZWFkZXIucG5nXCIpO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG5pb24tdGl0bGUge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmZmO1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuaW9uLWJ1dHRvbnMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDI1cHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xufVxuXG5pb24tZ3JpZCAuYXBwb2ludG1lbnRfcmVtaW5kZXIge1xuICBmb250LXNpemU6IDE1cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGNvbG9yOiAjNGM0YzRjO1xufVxuaW9uLWdyaWQgLmFwcG9pbnRtZW50X2RhdGUge1xuICBjb2xvcjogIzkyOTI5MjtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuaW9uLWdyaWQgLmFwcG9pbnRtZW50X3N0YXR1cyB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbn1cblxuaW9uLWxpc3Qge1xuICBwYWRkaW5nLXRvcDogMTBweDtcbiAgcGFkZGluZy1ib3R0b206IDEwcHg7XG59XG5cbi5zdF9wZW5kaW5nIHtcbiAgY29sb3I6ICNmZjljMDA7XG59XG5cbi5zdF9jbG9zZSB7XG4gIGNvbG9yOiAjZTMwMDAwO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/appointment/appointment.page.ts":
/*!*************************************************!*\
  !*** ./src/app/appointment/appointment.page.ts ***!
  \*************************************************/
/*! exports provided: AppointmentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppointmentPage", function() { return AppointmentPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _modal_modal_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../modal/modal.page */ "./src/app/modal/modal.page.ts");




let AppointmentPage = class AppointmentPage {
    constructor(modalController, platform, navCtrl) {
        this.modalController = modalController;
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.pt_active = false;
    }
    ngOnInit() {
        if (this.platform.is('android')) {
            this.pt_active = false;
        }
        else if (this.platform.is('ios')) {
            this.pt_active = true;
        }
    }
    goBack() {
        this.navCtrl.pop();
    }
    openModal() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _modal_modal_page__WEBPACK_IMPORTED_MODULE_3__["ModalPage"]
            });
            return yield modal.present();
        });
    }
};
AppointmentPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
AppointmentPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-appointment',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./appointment.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/appointment/appointment.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./appointment.page.scss */ "./src/app/appointment/appointment.page.scss")).default]
    })
], AppointmentPage);



/***/ }),

/***/ "./src/app/modal/modal.page.scss":
/*!***************************************!*\
  !*** ./src/app/modal/modal.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-toolbar {\n  padding-top: 0px !important;\n}\n\nion-header {\n  border-bottom: 1px solid #d7d7d7;\n}\n\n.icon_close {\n  background: #187bad;\n  color: #fff;\n  font-size: 20px;\n  border-radius: 50%;\n  padding: 5px;\n  font-weight: bold;\n}\n\n.modal_item {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  padding: 0px 0;\n  margin-left: 10px;\n  margin-right: 10px;\n  border-bottom: 1px solid #d7d7d7;\n}\n\n.modal_item_list {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  padding: 0px 0;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n\n.btn-modal {\n  font-size: 13px;\n  text-transform: initial;\n  margin-left: auto;\n  --background: #187bad;\n  --border-radius: unset;\n  --ion-font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.disable {\n  --background: #cacaca !important;\n}\n\n.item_clock {\n  color: #929292;\n  font-size: 14px;\n}\n\n.clock_img {\n  max-width: 20px;\n  width: 20px;\n  margin-right: 10px;\n}\n\n.btn-modal-cofirm {\n  width: 100%;\n  font-size: 16px;\n  text-transform: initial;\n  margin-left: auto;\n  --background: #187bad;\n  --border-radius: unset;\n  --ion-font-family: \"Century Gothic Regular\", sans-serif !important;\n  margin-bottom: 30px;\n}\n\n.modal_submit {\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  padding: 0px 0;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kYWwvRDpcXHRhc2tcXDIwMjAwNzA3XFx3b3JrXFxjaGlsZF9hcHAvc3JjXFxhcHBcXG1vZGFsXFxtb2RhbC5wYWdlLnNjc3MiLCJzcmMvYXBwL21vZGFsL21vZGFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLDJCQUFBO0FDQ0o7O0FERUE7RUFDSSxnQ0FBQTtBQ0NKOztBREVBO0VBQ0ksbUJBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7QUNDSjs7QURFQTtFQUNJLGFBQUE7RUFDQSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0EscUJBQUE7RUFDQSxzQkFBQTtFQUNBLGtFQUFBO0FDQ0o7O0FERUE7RUFDSSxnQ0FBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrRUFBQTtFQUNBLG1CQUFBO0FDQ0o7O0FERUE7RUFDSSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9tb2RhbC9tb2RhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXIge1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbn1cclxuXHJcbi5pY29uX2Nsb3NlIHtcclxuICAgIGJhY2tncm91bmQ6ICMxODdiYWQ7XHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHBhZGRpbmc6IDVweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG59XHJcblxyXG4ubW9kYWxfaXRlbSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDBweCAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2Q3ZDdkNztcclxufVxyXG5cclxuLm1vZGFsX2l0ZW1fbGlzdCB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDBweCAwO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbn1cclxuXHJcbi5idG4tbW9kYWwge1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIC0tYmFja2dyb3VuZDogIzE4N2JhZDtcclxuICAgIC0tYm9yZGVyLXJhZGl1czogdW5zZXQ7XHJcbiAgICAtLWlvbi1mb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmRpc2FibGUge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjY2FjYWNhICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5pdGVtX2Nsb2NrIHtcclxuICAgIGNvbG9yOiAjOTI5MjkyO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59XHJcblxyXG4uY2xvY2tfaW1nIHtcclxuICAgIG1heC13aWR0aDogMjBweDtcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG59XHJcblxyXG4uYnRuLW1vZGFsLWNvZmlybSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICAtLWJhY2tncm91bmQ6ICMxODdiYWQ7XHJcbiAgICAtLWJvcmRlci1yYWRpdXM6IHVuc2V0O1xyXG4gICAgLS1pb24tZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAzMHB4O1xyXG59XHJcblxyXG4ubW9kYWxfc3VibWl0IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGZsZXgtc3RhcnQ7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcGFkZGluZzogMHB4IDA7XHJcbiAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxufSIsImlvbi10b29sYmFyIHtcbiAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24taGVhZGVyIHtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkN2Q3ZDc7XG59XG5cbi5pY29uX2Nsb3NlIHtcbiAgYmFja2dyb3VuZDogIzE4N2JhZDtcbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBwYWRkaW5nOiA1cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4ubW9kYWxfaXRlbSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1zdGFydDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgcGFkZGluZzogMHB4IDA7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZDdkN2Q3O1xufVxuXG4ubW9kYWxfaXRlbV9saXN0IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAwcHggMDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn1cblxuLmJ0bi1tb2RhbCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICAtLWJhY2tncm91bmQ6ICMxODdiYWQ7XG4gIC0tYm9yZGVyLXJhZGl1czogdW5zZXQ7XG4gIC0taW9uLWZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4uZGlzYWJsZSB7XG4gIC0tYmFja2dyb3VuZDogI2NhY2FjYSAhaW1wb3J0YW50O1xufVxuXG4uaXRlbV9jbG9jayB7XG4gIGNvbG9yOiAjOTI5MjkyO1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbi5jbG9ja19pbWcge1xuICBtYXgtd2lkdGg6IDIwcHg7XG4gIHdpZHRoOiAyMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDEwcHg7XG59XG5cbi5idG4tbW9kYWwtY29maXJtIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XG4gIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICAtLWJhY2tncm91bmQ6ICMxODdiYWQ7XG4gIC0tYm9yZGVyLXJhZGl1czogdW5zZXQ7XG4gIC0taW9uLWZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xufVxuXG4ubW9kYWxfc3VibWl0IHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LXN0YXJ0O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nOiAwcHggMDtcbiAgbWFyZ2luLWxlZnQ6IDEwcHg7XG4gIG1hcmdpbi1yaWdodDogMTBweDtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/modal/modal.page.ts":
/*!*************************************!*\
  !*** ./src/app/modal/modal.page.ts ***!
  \*************************************/
/*! exports provided: ModalPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalPage", function() { return ModalPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let ModalPage = class ModalPage {
    constructor(modalController) {
        this.modalController = modalController;
    }
    ngOnInit() {
    }
    close() {
        this.modalController.dismiss();
    }
};
ModalPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
ModalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-modal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./modal.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/modal/modal.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./modal.page.scss */ "./src/app/modal/modal.page.scss")).default]
    })
], ModalPage);



/***/ })

}]);
//# sourceMappingURL=appointment-appointment-module-es2015.js.map