function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\n    <div class=\"bg\">\n        <ion-header [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n            <ion-toolbar>\n                <ion-buttons slot=\"start\" (click)=\"goBack()\">\n                    <ion-icon name=\"arrow-back\"></ion-icon>\n                </ion-buttons>\n                <ion-title>My Profile</ion-title>\n            </ion-toolbar>\n        </ion-header>\n        <ion-list class=\"profile_avata-box\">\n            <ion-input type=\"file\" class=\"photo_upload\" (change)=\"changeListener($event)\"></ion-input>\n            <ion-fab class=\"camera_pos\" vertical=\"top\" horizontal=\"end\" edge slot=\"fixed\">\n                <ion-fab-button class=\"camera_btn\">\n                    <ion-img class=\"camera_img\" [src]=\"this.camera\"></ion-img>\n                </ion-fab-button>\n            </ion-fab>\n            <ion-avatar>\n                <ion-img  [src]=\"this.profileimg\"></ion-img>\n            </ion-avatar>\n        </ion-list>\n        <ion-fab class=\"edit_pos\" vertical=\"top\" horizontal=\"end\" edge slot=\"fixed\" (click)=\"change_edit(1)\" *ngIf=\"!edit_status\">\n            <ion-fab-button class=\"camera_btn\">\n                <ion-img class=\"camera_img\" [src]=\"this.edit\"></ion-img>\n            </ion-fab-button>\n        </ion-fab>\n        <ion-fab class=\"edit_pos\" vertical=\"top\" horizontal=\"end\" edge slot=\"fixed\" (click)=\"change_edit(0)\" *ngIf=\"edit_status\">\n            <ion-fab-button class=\"camera_btn\">\n                <ion-img class=\"camera_img\" [src]=\"this.close\"></ion-img>\n            </ion-fab-button>\n        </ion-fab>\n    </div>\n    <ion-list class=\"profile_content\">\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-label class=\"picture_title\">\n                        Basic information\n                    </ion-label>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Fisrt name of child</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Last name of child</ion-label>\n                    <ion-input type=\"text\" value=\"Ahmed\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Fisrt name of child</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Last name of child</ion-label>\n                    <ion-input type=\"text\" value=\"Ahmed\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\">Nationality</ion-label>\n                    <ion-select value=\"f\" placeholder=\"Nationality\">\n                        <ion-select-option value=\"f\">Pakistani</ion-select-option>\n                        <ion-select-option value=\"m\">Vietnam</ion-select-option>\n                    </ion-select>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Name of the class</ion-label>\n                    <ion-select value=\"f\" placeholder=\"Name of the class\">\n                        <ion-select-option value=\"f\" selected>Bamboo</ion-select-option>\n                        <ion-select-option value=\"m\">Bamboo 2</ion-select-option>\n                    </ion-select>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-label class=\"input_label\">Address</ion-label>\n                    <ion-input type=\"text\" value=\"3th Capital Street, karachi, Pakistan\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Mother’s first name</ion-label>\n                    <ion-input type=\"text\" value=\"Neha\"></ion-input>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\">Mother’s last name</ion-label>\n                    <ion-input type=\"text\" value=\"Mahdy\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Mother’s phone number</ion-label>\n                    <ion-input type=\"text\" value=\"Neha\"></ion-input>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\">Mother’s email</ion-label>\n                    <ion-input type=\"text\" value=\"Mahdy\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\"> Father’s phone number</ion-label>\n                    <ion-input type=\"text\" value=\"Neha\"></ion-input>\n                </ion-col>\n                <ion-col size=\"6\">\n                    <ion-label class=\"input_label\">Father’s email</ion-label>\n                    <ion-input type=\"text\" value=\"Mahdy\"></ion-input>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-label class=\"picture_title\">\n                        Emergency contact\n                    </ion-label>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Email</ion-label>\n                    <ion-input type=\"text\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Email</ion-label>\n                    <ion-input type=\"text\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Email</ion-label>\n                    <ion-input type=\"text\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-label class=\"picture_title\">\n                        Pick up authorization person\n                    </ion-label>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">First Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Last Name</ion-label>\n                    <ion-input type=\"text\" value=\"Mohamed\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Photo</ion-label>\n                    <ion-input class=\"file_input\" type=\"file\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">First Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Last Name</ion-label>\n                    <ion-input type=\"text\" value=\"Mohamed\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Photo</ion-label>\n                    <ion-input class=\"file_input\" type=\"file\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">First Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Last Name</ion-label>\n                    <ion-input type=\"text\" value=\"Mohamed\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Photo</ion-label>\n                    <ion-input class=\"file_input\" type=\"file\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">First Name</ion-label>\n                    <ion-input type=\"text\" value=\"Ali\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Last Name</ion-label>\n                    <ion-input type=\"text\" value=\"Mohamed\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Photo</ion-label>\n                    <ion-input class=\"file_input\" type=\"file\" value=\"ali@gmail.com\"></ion-input>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-label class=\"input_label\">Phone</ion-label>\n                    <ion-input type=\"text\" value=\"+02 255 3273\"></ion-input>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n        <ion-grid>\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-label class=\"picture_title\">\n                        Childs Health details\n                    </ion-label>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Allergies</ion-label>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Food restrictions</ion-label>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-label class=\"input_label\">Any health issues ?</ion-label>\n                </ion-col>\n            </ion-row>\n            <ion-row class=\"mt-0\">\n                <ion-col size=\"4\">\n                    <ion-textarea rows=\"3\" cols=\"20\" placeholder=\"Write Comment\"></ion-textarea>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-textarea rows=\"3\" cols=\"20\" placeholder=\"Write Comment\"></ion-textarea>\n                </ion-col>\n                <ion-col size=\"4\">\n                    <ion-textarea rows=\"3\" cols=\"20\" placeholder=\"Write Comment\"></ion-textarea>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n        <ion-grid *ngIf=\"edit_status\">\n            <ion-row>\n                <ion-col size=\"12\">\n                    <ion-button class=\"btn-market\" expand=\"full\">Save</ion-button>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/profile/profile-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/profile/profile-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: ProfilePageRoutingModule */

  /***/
  function srcAppProfileProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
      return ProfilePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");

    var routes = [{
      path: '',
      component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
    }];

    var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
      _classCallCheck(this, ProfilePageRoutingModule);
    };

    ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ProfilePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.module.ts ***!
    \*******************************************/

  /*! exports provided: ProfilePageModule */

  /***/
  function srcAppProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
      return ProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./profile-routing.module */
    "./src/app/profile/profile-routing.module.ts");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/profile/profile.page.ts");

    var ProfilePageModule = function ProfilePageModule() {
      _classCallCheck(this, ProfilePageModule);
    };

    ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]],
      declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })], ProfilePageModule);
    /***/
  },

  /***/
  "./src/app/profile/profile.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/profile/profile.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".bg {\n  background: url('bg-profile.png') no-repeat top center;\n  width: 100%;\n  height: 250px;\n  background-size: cover;\n  background-position: top center;\n}\n\nion-toolbar {\n  padding-top: 0px !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #383838;\n}\n\n.photo_upload {\n  position: absolute;\n  width: 50px;\n  top: -20px;\n  /* right: 0px; */\n  margin-left: 46px;\n  opacity: 0;\n  z-index: 10000;\n}\n\nion-title {\n  text-align: center;\n  color: #383838;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.profile_avata-box {\n  background: unset;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 100%;\n  height: 50%;\n  position: relative;\n  top: 25px;\n}\n\n.profile_avata-box ion-avatar {\n  width: 120px;\n  height: 120px;\n  background: white;\n  padding: 5px;\n  border: 5px solid #187bad;\n}\n\n.camera_pos {\n  position: absolute;\n  top: 0;\n  right: 32%;\n}\n\n.camera_btn {\n  --background: #187bad;\n  width: 40px;\n  height: 40px;\n}\n\n.camera_img {\n  max-width: 20px;\n  width: 20px;\n  height: 20px;\n}\n\n.edit_pos {\n  right: 10px;\n  position: absolute;\n  top: 230px;\n}\n\n.profile_content {\n  align-items: flex-start;\n  width: 100%;\n}\n\n.picture_title {\n  color: #545454;\n  text-transform: uppercase;\n  font-size: 16px;\n  font-weight: 500;\n}\n\n.input_label {\n  font-size: 14px;\n  color: #8d8d8d;\n}\n\n.file_input {\n  --padding-top: 7px;\n  --padding-bottom: 7px;\n}\n\nion-input,\nion-select,\nion-textarea {\n  font-size: 14px;\n  margin-top: 10px;\n  font-weight: 600;\n  border: 1px solid #d7d7d7;\n  color: #555555 !important;\n}\n\nion-row {\n  margin-top: 20px;\n}\n\n.pt-23 {\n  padding-top: 23px;\n}\n\n.btn-market {\n  --background: #187bad;\n  width: 100%;\n  color: white;\n  text-transform: initial;\n  font-size: 16px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9EOlxcdGFza1xcMjAyMDA3MDdcXHdvcmtcXGNoaWxkX2FwcC9zcmNcXGFwcFxccHJvZmlsZVxccHJvZmlsZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzREFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSwrQkFBQTtBQ0NKOztBREVBO0VBQ0ksMkJBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLGNBQUE7RUFDQSw0REFBQTtBQ0NKOztBREVBO0VBQ0ksaUJBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0FDQ0o7O0FEQUk7RUFDSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0FDRVI7O0FERUE7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxVQUFBO0FDQ0o7O0FERUE7RUFDSSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUNDSjs7QURFQTtFQUNJLHVCQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQ0NKOztBREVBOzs7RUFHSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLHlCQUFBO0VBQ0EseUJBQUE7QUNDSjs7QURFQTtFQUNJLGdCQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtBQ0NKOztBREVBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLDREQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJnIHtcclxuICAgIGJhY2tncm91bmQ6IHVybCgnLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy1wcm9maWxlLnBuZycpIG5vLXJlcGVhdCB0b3AgY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDI1MHB4O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgIGJhY2tncm91bmQtcG9zaXRpb246IHRvcCBjZW50ZXI7XHJcbn1cclxuXHJcbmlvbi10b29sYmFyIHtcclxuICAgIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcclxufVxyXG5cclxuaW9uLWJ1dHRvbnMgaW9uLWljb24ge1xyXG4gICAgZm9udC1zaXplOiAyNXB4O1xyXG4gICAgY29sb3I6ICMzODM4Mzg7XHJcbn1cclxuXHJcbi5waG90b191cGxvYWQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgd2lkdGg6IDUwcHg7XHJcbiAgICB0b3A6IC0yMHB4O1xyXG4gICAgLyogcmlnaHQ6IDBweDsgKi9cclxuICAgIG1hcmdpbi1sZWZ0OiA0NnB4O1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIHotaW5kZXg6IDEwMDAwO1xyXG59XHJcblxyXG5pb24tdGl0bGUge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMzODM4Mzg7XHJcbiAgICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnByb2ZpbGVfYXZhdGEtYm94IHtcclxuICAgIGJhY2tncm91bmQ6IHVuc2V0O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA1MCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0b3A6IDI1cHg7XHJcbiAgICBpb24tYXZhdGFyIHtcclxuICAgICAgICB3aWR0aDogMTIwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAxMjBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgICAgICBwYWRkaW5nOiA1cHg7XHJcbiAgICAgICAgYm9yZGVyOiA1cHggc29saWQgIzE4N2JhZDtcclxuICAgIH1cclxufVxyXG5cclxuLmNhbWVyYV9wb3Mge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAwO1xyXG4gICAgcmlnaHQ6IDMyJTtcclxufVxyXG5cclxuLmNhbWVyYV9idG4ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMTg3YmFkO1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbn1cclxuXHJcbi5jYW1lcmFfaW1nIHtcclxuICAgIG1heC13aWR0aDogMjBweDtcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG59XHJcblxyXG4uZWRpdF9wb3Mge1xyXG4gICAgcmlnaHQ6IDEwcHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDIzMHB4O1xyXG59XHJcblxyXG4ucHJvZmlsZV9jb250ZW50IHtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbn1cclxuXHJcbi5waWN0dXJlX3RpdGxlIHtcclxuICAgIGNvbG9yOiAjNTQ1NDU0O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbn1cclxuXHJcbi5pbnB1dF9sYWJlbCB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogIzhkOGQ4ZDtcclxufVxyXG5cclxuLmZpbGVfaW5wdXQge1xyXG4gICAgLS1wYWRkaW5nLXRvcDogN3B4O1xyXG4gICAgLS1wYWRkaW5nLWJvdHRvbTogN3B4O1xyXG59XHJcblxyXG5pb24taW5wdXQsXHJcbmlvbi1zZWxlY3QsXHJcbmlvbi10ZXh0YXJlYSB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XHJcbiAgICBjb2xvcjogIzU1NTU1NSAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5pb24tcm93IHtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbn1cclxuXHJcbi5wdC0yMyB7XHJcbiAgICBwYWRkaW5nLXRvcDogMjNweDtcclxufVxyXG5cclxuLmJ0bi1tYXJrZXQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMTg3YmFkO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG59IiwiLmJnIHtcbiAgYmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9iZy1wcm9maWxlLnBuZ1wiKSBuby1yZXBlYXQgdG9wIGNlbnRlcjtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMjUwcHg7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IHRvcCBjZW50ZXI7XG59XG5cbmlvbi10b29sYmFyIHtcbiAgcGFkZGluZy10b3A6IDBweCAhaW1wb3J0YW50O1xufVxuXG5pb24tYnV0dG9ucyBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICMzODM4Mzg7XG59XG5cbi5waG90b191cGxvYWQge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiA1MHB4O1xuICB0b3A6IC0yMHB4O1xuICAvKiByaWdodDogMHB4OyAqL1xuICBtYXJnaW4tbGVmdDogNDZweDtcbiAgb3BhY2l0eTogMDtcbiAgei1pbmRleDogMTAwMDA7XG59XG5cbmlvbi10aXRsZSB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMzODM4Mzg7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuXG4ucHJvZmlsZV9hdmF0YS1ib3gge1xuICBiYWNrZ3JvdW5kOiB1bnNldDtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDUwJTtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICB0b3A6IDI1cHg7XG59XG4ucHJvZmlsZV9hdmF0YS1ib3ggaW9uLWF2YXRhciB7XG4gIHdpZHRoOiAxMjBweDtcbiAgaGVpZ2h0OiAxMjBweDtcbiAgYmFja2dyb3VuZDogd2hpdGU7XG4gIHBhZGRpbmc6IDVweDtcbiAgYm9yZGVyOiA1cHggc29saWQgIzE4N2JhZDtcbn1cblxuLmNhbWVyYV9wb3Mge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMDtcbiAgcmlnaHQ6IDMyJTtcbn1cblxuLmNhbWVyYV9idG4ge1xuICAtLWJhY2tncm91bmQ6ICMxODdiYWQ7XG4gIHdpZHRoOiA0MHB4O1xuICBoZWlnaHQ6IDQwcHg7XG59XG5cbi5jYW1lcmFfaW1nIHtcbiAgbWF4LXdpZHRoOiAyMHB4O1xuICB3aWR0aDogMjBweDtcbiAgaGVpZ2h0OiAyMHB4O1xufVxuXG4uZWRpdF9wb3Mge1xuICByaWdodDogMTBweDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDIzMHB4O1xufVxuXG4ucHJvZmlsZV9jb250ZW50IHtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIHdpZHRoOiAxMDAlO1xufVxuXG4ucGljdHVyZV90aXRsZSB7XG4gIGNvbG9yOiAjNTQ1NDU0O1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG59XG5cbi5pbnB1dF9sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM4ZDhkOGQ7XG59XG5cbi5maWxlX2lucHV0IHtcbiAgLS1wYWRkaW5nLXRvcDogN3B4O1xuICAtLXBhZGRpbmctYm90dG9tOiA3cHg7XG59XG5cbmlvbi1pbnB1dCxcbmlvbi1zZWxlY3QsXG5pb24tdGV4dGFyZWEge1xuICBmb250LXNpemU6IDE0cHg7XG4gIG1hcmdpbi10b3A6IDEwcHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q3ZDc7XG4gIGNvbG9yOiAjNTU1NTU1ICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1yb3cge1xuICBtYXJnaW4tdG9wOiAyMHB4O1xufVxuXG4ucHQtMjMge1xuICBwYWRkaW5nLXRvcDogMjNweDtcbn1cblxuLmJ0bi1tYXJrZXQge1xuICAtLWJhY2tncm91bmQ6ICMxODdiYWQ7XG4gIHdpZHRoOiAxMDAlO1xuICBjb2xvcjogd2hpdGU7XG4gIHRleHQtdHJhbnNmb3JtOiBpbml0aWFsO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/profile/profile.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/profile/profile.page.ts ***!
    \*****************************************/

  /*! exports provided: ProfilePage */

  /***/
  function srcAppProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
      return ProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ProfilePage = /*#__PURE__*/function () {
      function ProfilePage(platform, navCtrl) {
        _classCallCheck(this, ProfilePage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.camera = 'assets/images/icon-camera.png';
        this.edit = 'assets/images/icon-edit.png';
        this.close = 'assets/images/icon-close.png';
        this.profileimg = 'assets/images/img-avata.png';
        this.edit_status = false;
        this.pt_active = false;
      }

      _createClass(ProfilePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }, {
        key: "changeListener",
        value: function changeListener($event) {
          this.profileimg = 'assets/images/bg-profile.png';
        }
      }, {
        key: "change_edit",
        value: function change_edit(p) {
          if (p === 1) {
            this.edit_status = true;
          } else {
            this.edit_status = false;
          }
        }
      }]);

      return ProfilePage;
    }();

    ProfilePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-profile',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./profile.page.scss */
      "./src/app/profile/profile.page.scss"))["default"]]
    })], ProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=profile-profile-module-es5.js.map