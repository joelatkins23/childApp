(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["messagedetail-messagedetail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/messagedetail/messagedetail.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/messagedetail/messagedetail.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\" (click)=\"goBack()\">\n            <ion-icon name=\"arrow-back\"></ion-icon>\n        </ion-buttons>\n\n        <ion-buttons slot=\"end\">\n            <ion-icon name=\"trash\"></ion-icon>\n            <ion-icon name=\"md-more\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-list class=\"header_info\">\n        <ion-item>\n            <ion-text>Message 1</ion-text>\n            <div class=\"img\">\n                <img src=\"../../assets/images/icon-star.png\" alt=\"\">\n            </div>\n        </ion-item>\n    </ion-list>\n    <ion-grid>\n        <ion-row>\n            <ion-col size=\"2\">\n                <ion-avatar>\n                    <img src=\"../../assets/images/img-avataa.png\">\n                </ion-avatar>\n            </ion-col>\n            <ion-col size=\"8\">\n                <ion-label class=\"mail\">Adminstration@gmail.com</ion-label>\n                <ion-label class=\"to\">to me</ion-label>\n                <ion-label class=\"msg_time\">8:50 PM</ion-label>\n            </ion-col>\n            <ion-col size=\"2\">\n                <ion-icon name=\"ios-undo\"></ion-icon>\n                <ion-icon name=\"md-more\"></ion-icon>\n            </ion-col>\n        </ion-row>\n        <ion-row>\n            <ion-col size=\"12\">\n                <ion-label class=\"mail mt-20\">Hi Ay,</ion-label>\n                <ion-label class=\"content_txt\">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</ion-label>\n                <ion-label class=\"content_txt\">Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into\n                    electronic typesetting, remaining essentially unchanged.</ion-label>\n                <ion-label class=\"content_txt\">It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</ion-label>\n                <ion-label class=\"mail\">Thanks</ion-label>\n            </ion-col>\n\n        </ion-row>\n    </ion-grid>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/messagedetail/messagedetail-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/messagedetail/messagedetail-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: MessagedetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagedetailPageRoutingModule", function() { return MessagedetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _messagedetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./messagedetail.page */ "./src/app/messagedetail/messagedetail.page.ts");




const routes = [
    {
        path: '',
        component: _messagedetail_page__WEBPACK_IMPORTED_MODULE_3__["MessagedetailPage"]
    }
];
let MessagedetailPageRoutingModule = class MessagedetailPageRoutingModule {
};
MessagedetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MessagedetailPageRoutingModule);



/***/ }),

/***/ "./src/app/messagedetail/messagedetail.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/messagedetail/messagedetail.module.ts ***!
  \*******************************************************/
/*! exports provided: MessagedetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagedetailPageModule", function() { return MessagedetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _messagedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./messagedetail-routing.module */ "./src/app/messagedetail/messagedetail-routing.module.ts");
/* harmony import */ var _messagedetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./messagedetail.page */ "./src/app/messagedetail/messagedetail.page.ts");







let MessagedetailPageModule = class MessagedetailPageModule {
};
MessagedetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _messagedetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["MessagedetailPageRoutingModule"]
        ],
        declarations: [_messagedetail_page__WEBPACK_IMPORTED_MODULE_6__["MessagedetailPage"]]
    })
], MessagedetailPageModule);



/***/ }),

/***/ "./src/app/messagedetail/messagedetail.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/messagedetail/messagedetail.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\n.header_info ion-text {\n  width: 80%;\n  color: #424242;\n  font-weight: 600;\n  font-size: 18px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.header_info .img {\n  width: 20%;\n  text-align: right;\n}\n\n.header_info .img img {\n  width: 25px;\n}\n\nion-avatar {\n  width: 50px;\n  height: 50px;\n}\n\nion-col ion-icon {\n  font-size: 25px;\n  color: #424242;\n  display: table-cell;\n  padding-top: 15px;\n}\n\nion-item {\n  margin-right: 15px;\n  --inner-padding-end: 0px;\n}\n\n.mail {\n  color: #424242;\n  font-size: 16px;\n  font-weight: 600;\n  display: block;\n}\n\n.to {\n  color: #797979;\n  font-size: 14px;\n  display: block;\n}\n\n.msg_time {\n  color: #187bad !important;\n  font-size: 14px;\n  display: block;\n}\n\n.content_txt {\n  color: #424242;\n  font-size: 16px;\n  margin-bottom: 15px;\n  display: block;\n}\n\n.r_content {\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  flex-direction: column;\n  padding: 0;\n  width: calc(100% - 50px);\n  margin-left: 10px;\n}\n\n.massages_list {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  font-size: 14px;\n  font-weight: 500;\n  padding: 0;\n  margin-bottom: 10px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.massages_list ion-text {\n  color: #187bad;\n  width: 80%;\n  display: flex;\n  font-size: 14px;\n}\n\n.massages_list ion-label {\n  color: #8d8d8d;\n  font-size: 14px;\n}\n\n.massages_list .msg_time {\n  color: #187bad !important;\n  text-align: right;\n  font-size: 14px;\n}\n\nion-list {\n  padding-top: 10px;\n  padding-bottom: 10px;\n}\n\n.massages_des {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  align-items: flex-start;\n  font-size: 14px;\n  font-weight: 500;\n  padding: 0;\n  margin-bottom: 10px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\n.massages_des ion-text {\n  color: #8d8d8d;\n  width: 80%;\n  display: flex;\n  font-size: 14px;\n}\n\n.massages_des img {\n  width: 25px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZWRldGFpbC9EOlxcdGFza1xcMjAyMDA3MDdcXHdvcmtcXGNoaWxkX2FwcC9zcmNcXGFwcFxcbWVzc2FnZWRldGFpbFxcbWVzc2FnZWRldGFpbC5wYWdlLnNjc3MiLCJzcmMvYXBwL21lc3NhZ2VkZXRhaWwvbWVzc2FnZWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzQ0FBQTtFQUNBLHNCQUFBO0FDQ0o7O0FERUE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQ0NKOztBREVBO0VBQ0ksVUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSw0REFBQTtBQ0NKOztBREVBO0VBQ0ksVUFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FEQUk7RUFDSSxXQUFBO0FDRVI7O0FERUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLHdCQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBQ0NKOztBREVBO0VBQ0ksYUFBQTtFQUNBLDhCQUFBO0VBQ0EsdUJBQUE7RUFDQSxzQkFBQTtFQUNBLFVBQUE7RUFDQSx3QkFBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSw0REFBQTtBQ0NKOztBREFJO0VBQ0ksY0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0VSOztBREFJO0VBQ0ksY0FBQTtFQUNBLGVBQUE7QUNFUjs7QURBSTtFQUNJLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0FDRVI7O0FERUE7RUFDSSxpQkFBQTtFQUNBLG9CQUFBO0FDQ0o7O0FERUE7RUFDSSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSw0REFBQTtBQ0NKOztBREFJO0VBQ0ksY0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQ0VSOztBREFJO0VBQ0ksV0FBQTtBQ0VSIiwiZmlsZSI6InNyYy9hcHAvbWVzc2FnZWRldGFpbC9tZXNzYWdlZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXIge1xyXG4gICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1hZ2VzL2JnLWhlYWRlci5wbmcnKTtcclxuICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbn1cclxuXHJcbmlvbi1idXR0b25zIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4uaGVhZGVyX2luZm8gaW9uLXRleHQge1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIGNvbG9yOiAjNDI0MjQyO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4uaGVhZGVyX2luZm8gLmltZyB7XHJcbiAgICB3aWR0aDogMjAlO1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAyNXB4O1xyXG4gICAgfVxyXG59XHJcblxyXG5pb24tYXZhdGFyIHtcclxuICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG59XHJcblxyXG5pb24tY29sIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjNDI0MjQyO1xyXG4gICAgZGlzcGxheTogdGFibGUtY2VsbDtcclxuICAgIHBhZGRpbmctdG9wOiAxNXB4O1xyXG59XHJcblxyXG5pb24taXRlbSB7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1cHg7XHJcbiAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwcHg7XHJcbn1cclxuXHJcbi5tYWlsIHtcclxuICAgIGNvbG9yOiAjNDI0MjQyO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4udG8ge1xyXG4gICAgY29sb3I6ICM3OTc5Nzk7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLm1zZ190aW1lIHtcclxuICAgIGNvbG9yOiAjMTg3YmFkICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLmNvbnRlbnRfdHh0IHtcclxuICAgIGNvbG9yOiAjNDI0MjQyO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4ucl9jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgd2lkdGg6IGNhbGMoMTAwJSAtIDUwcHgpO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbn1cclxuXHJcbi5tYXNzYWdlc19saXN0IHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICBpb24tdGV4dCB7XHJcbiAgICAgICAgY29sb3I6ICMxODdiYWQ7XHJcbiAgICAgICAgd2lkdGg6IDgwJTtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgY29sb3I6ICM4ZDhkOGQ7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgfVxyXG4gICAgLm1zZ190aW1lIHtcclxuICAgICAgICBjb2xvcjogIzE4N2JhZCAhaW1wb3J0YW50O1xyXG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLm1hc3NhZ2VzX2RlcyB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgaW9uLXRleHQge1xyXG4gICAgICAgIGNvbG9yOiAjOGQ4ZDhkO1xyXG4gICAgICAgIHdpZHRoOiA4MCU7XHJcbiAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB9XHJcbiAgICBpbWcge1xyXG4gICAgICAgIHdpZHRoOiAyNXB4O1xyXG4gICAgfVxyXG59IiwiaW9uLWhlYWRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuaW9uLWJ1dHRvbnMgaW9uLWljb24ge1xuICBmb250LXNpemU6IDI1cHg7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG4uaGVhZGVyX2luZm8gaW9uLXRleHQge1xuICB3aWR0aDogODAlO1xuICBjb2xvcjogIzQyNDI0MjtcbiAgZm9udC13ZWlnaHQ6IDYwMDtcbiAgZm9udC1zaXplOiAxOHB4O1xuICBmb250LWZhbWlseTogXCJDZW50dXJ5IEdvdGhpYyBSZWd1bGFyXCIsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcbn1cblxuLmhlYWRlcl9pbmZvIC5pbWcge1xuICB3aWR0aDogMjAlO1xuICB0ZXh0LWFsaWduOiByaWdodDtcbn1cbi5oZWFkZXJfaW5mbyAuaW1nIGltZyB7XG4gIHdpZHRoOiAyNXB4O1xufVxuXG5pb24tYXZhdGFyIHtcbiAgd2lkdGg6IDUwcHg7XG4gIGhlaWdodDogNTBweDtcbn1cblxuaW9uLWNvbCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMjVweDtcbiAgY29sb3I6ICM0MjQyNDI7XG4gIGRpc3BsYXk6IHRhYmxlLWNlbGw7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xufVxuXG5pb24taXRlbSB7XG4gIG1hcmdpbi1yaWdodDogMTVweDtcbiAgLS1pbm5lci1wYWRkaW5nLWVuZDogMHB4O1xufVxuXG4ubWFpbCB7XG4gIGNvbG9yOiAjNDI0MjQyO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGRpc3BsYXk6IGJsb2NrO1xufVxuXG4udG8ge1xuICBjb2xvcjogIzc5Nzk3OTtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLm1zZ190aW1lIHtcbiAgY29sb3I6ICMxODdiYWQgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBkaXNwbGF5OiBibG9jaztcbn1cblxuLmNvbnRlbnRfdHh0IHtcbiAgY29sb3I6ICM0MjQyNDI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWJvdHRvbTogMTVweDtcbiAgZGlzcGxheTogYmxvY2s7XG59XG5cbi5yX2NvbnRlbnQge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBwYWRkaW5nOiAwO1xuICB3aWR0aDogY2FsYygxMDAlIC0gNTBweCk7XG4gIG1hcmdpbi1sZWZ0OiAxMHB4O1xufVxuXG4ubWFzc2FnZXNfbGlzdCB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIHBhZGRpbmc6IDA7XG4gIG1hcmdpbi1ib3R0b206IDEwcHg7XG4gIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xufVxuLm1hc3NhZ2VzX2xpc3QgaW9uLXRleHQge1xuICBjb2xvcjogIzE4N2JhZDtcbiAgd2lkdGg6IDgwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLm1hc3NhZ2VzX2xpc3QgaW9uLWxhYmVsIHtcbiAgY29sb3I6ICM4ZDhkOGQ7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYXNzYWdlc19saXN0IC5tc2dfdGltZSB7XG4gIGNvbG9yOiAjMTg3YmFkICFpbXBvcnRhbnQ7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBmb250LXNpemU6IDE0cHg7XG59XG5cbmlvbi1saXN0IHtcbiAgcGFkZGluZy10b3A6IDEwcHg7XG4gIHBhZGRpbmctYm90dG9tOiAxMHB4O1xufVxuXG4ubWFzc2FnZXNfZGVzIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgZm9udC13ZWlnaHQ6IDUwMDtcbiAgcGFkZGluZzogMDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG4ubWFzc2FnZXNfZGVzIGlvbi10ZXh0IHtcbiAgY29sb3I6ICM4ZDhkOGQ7XG4gIHdpZHRoOiA4MCU7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5tYXNzYWdlc19kZXMgaW1nIHtcbiAgd2lkdGg6IDI1cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/messagedetail/messagedetail.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/messagedetail/messagedetail.page.ts ***!
  \*****************************************************/
/*! exports provided: MessagedetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagedetailPage", function() { return MessagedetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let MessagedetailPage = class MessagedetailPage {
    constructor(platform, navCtrl) {
        this.platform = platform;
        this.navCtrl = navCtrl;
        this.pt_active = false;
    }
    ngOnInit() {
        if (this.platform.is('android')) {
            this.pt_active = false;
        }
        else if (this.platform.is('ios')) {
            this.pt_active = true;
        }
    }
    goBack() {
        this.navCtrl.pop();
    }
    goto(p) {
        this.navCtrl.navigateForward(p);
    }
};
MessagedetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"] }
];
MessagedetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-messagedetail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./messagedetail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/messagedetail/messagedetail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./messagedetail.page.scss */ "./src/app/messagedetail/messagedetail.page.scss")).default]
    })
], MessagedetailPage);



/***/ })

}]);
//# sourceMappingURL=messagedetail-messagedetail-module-es2015.js.map