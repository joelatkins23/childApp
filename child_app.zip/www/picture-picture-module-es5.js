function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["picture-picture-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/picture/picture.page.html":
  /*!*********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/picture/picture.page.html ***!
    \*********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPicturePicturePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar [ngClass]=\"pt_active? 'ios_active':'ad_active'\">\n        <ion-buttons slot=\"start\">\n            <ion-icon name=\"arrow-back\" *ngIf=\"!deleteitems\" (click)=\"goBack()\"></ion-icon>\n            <ion-icon name=\"close\" *ngIf=\"deleteitems\" (click)=\"close()\"></ion-icon>\n        </ion-buttons>\n        <ion-title>{{title}}</ion-title>\n        <ion-buttons slot=\"end\" *ngIf=\"deleteitems\">\n            <ion-icon name=\"trash\"></ion-icon>\n            <ion-icon name=\"md-more\"></ion-icon>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n<ion-content>\n    <ion-list class=\"picture_list mb-15\">\n        <ion-grid>\n            <ion-grid>\n                <ion-col size=\"12\">\n                    <ion-text class=\"date_text\">5 June 2020</ion-text>\n                </ion-col>\n            </ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(1, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected \" [ngClass]=\"found(1) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list \" [ngClass]=\"found(1) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(2, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(2) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(2) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(3, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(3) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(3) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(4, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(4) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(4) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-list>\n    <ion-list class=\"picture_list mb-15\">\n        <ion-grid>\n            <ion-grid>\n                <ion-col size=\"12\">\n                    <ion-text class=\"date_text\">6 May 2019</ion-text>\n                </ion-col>\n            </ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(5, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(5) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(5) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(6, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(6) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(6) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(7, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(7) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(7) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(8, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(8) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(8) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-list>\n    <ion-list class=\"picture_list mb-15\">\n        <ion-grid>\n            <ion-grid>\n                <ion-col size=\"12\">\n                    <ion-text class=\"date_text\">6 May 2019</ion-text>\n                </ion-col>\n            </ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(9, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(9) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(9) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(10, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(10) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(10) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(11, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(11) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(11) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(12, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(12) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(12) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(13, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(13) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(13) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(14, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(14) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(14) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(15, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(15) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(15) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(16, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(16) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(16) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-list>\n    <ion-list class=\"picture_list mb-15\">\n        <ion-grid>\n            <ion-grid>\n                <ion-col size=\"12\">\n                    <ion-text class=\"date_text\">6 May 2019</ion-text>\n                </ion-col>\n            </ion-grid>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(17, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(17) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(17) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(18, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(18) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(18) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(19, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(19) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(19) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(20, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(20) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(20) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n            <ion-row>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(21, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(21) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(21) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(22, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(22) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(22) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select2.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(23, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(23) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(23) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select3.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n                <ion-col size=\"3\">\n                    <ion-checkbox class=\"picture__rdo\" (ionChange)=\"setChecked(24, $event.detail.checked)\"></ion-checkbox>\n                    <ion-img class=\"icon picture_selected\" [ngClass]=\"found(24) ? 'picture_selected--show':'normal'\" src=\"assets/images/icon-selected.png\"></ion-img>\n                    <ion-list class=\"picture_item_list\" [ngClass]=\"found(24) ? 'picture_item_list--selected':'normal'\">\n                        <ion-img class=\"img img--fruit\" src=\"assets/images/img-select4.png\"></ion-img>\n                    </ion-list>\n                </ion-col>\n            </ion-row>\n        </ion-grid>\n    </ion-list>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/picture/picture-routing.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/picture/picture-routing.module.ts ***!
    \***************************************************/

  /*! exports provided: PicturePageRoutingModule */

  /***/
  function srcAppPicturePictureRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PicturePageRoutingModule", function () {
      return PicturePageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _picture_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./picture.page */
    "./src/app/picture/picture.page.ts");

    var routes = [{
      path: '',
      component: _picture_page__WEBPACK_IMPORTED_MODULE_3__["PicturePage"]
    }];

    var PicturePageRoutingModule = function PicturePageRoutingModule() {
      _classCallCheck(this, PicturePageRoutingModule);
    };

    PicturePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], PicturePageRoutingModule);
    /***/
  },

  /***/
  "./src/app/picture/picture.module.ts":
  /*!*******************************************!*\
    !*** ./src/app/picture/picture.module.ts ***!
    \*******************************************/

  /*! exports provided: PicturePageModule */

  /***/
  function srcAppPicturePictureModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PicturePageModule", function () {
      return PicturePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _picture_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./picture-routing.module */
    "./src/app/picture/picture-routing.module.ts");
    /* harmony import */


    var _picture_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./picture.page */
    "./src/app/picture/picture.page.ts");

    var PicturePageModule = function PicturePageModule() {
      _classCallCheck(this, PicturePageModule);
    };

    PicturePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _picture_routing_module__WEBPACK_IMPORTED_MODULE_5__["PicturePageRoutingModule"]],
      declarations: [_picture_page__WEBPACK_IMPORTED_MODULE_6__["PicturePage"]]
    })], PicturePageModule);
    /***/
  },

  /***/
  "./src/app/picture/picture.page.scss":
  /*!*******************************************!*\
    !*** ./src/app/picture/picture.page.scss ***!
    \*******************************************/

  /*! exports provided: default */

  /***/
  function srcAppPicturePicturePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background-image: url('bg-header.png');\n  background-size: cover;\n}\n\nion-title {\n  text-align: center;\n  color: #fff;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n\nion-buttons ion-icon {\n  font-size: 25px;\n  color: #fff;\n}\n\n.picture_list {\n  padding: 0 20px;\n  margin-top: 10px;\n}\n\n.date_text {\n  font-size: 14px;\n  color: #4f4f4f;\n}\n\n.picture_item_list {\n  padding-top: 0px !important;\n  padding-bottom: 0px !important;\n}\n\n.picture_item_list--selected {\n  margin: 5px;\n}\n\n.picture_selected {\n  width: 20px;\n  position: absolute;\n  z-index: 99;\n  top: 0px;\n  left: 0px;\n  display: none;\n}\n\n.picture_selected--show {\n  display: block !important;\n}\n\n.picture__rdo {\n  opacity: 0;\n  position: absolute;\n  width: 100%;\n  height: 100%;\n}\n\n.btn-market {\n  --background: #187bad;\n  width: 100%;\n  color: white;\n  text-transform: initial;\n  font-size: 16px;\n  font-family: \"Century Gothic Regular\", sans-serif !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGljdHVyZS9EOlxcdGFza1xcMjAyMDA3MDdcXHdvcmtcXGNoaWxkX2FwcC9zcmNcXGFwcFxccGljdHVyZVxccGljdHVyZS5wYWdlLnNjc3MiLCJzcmMvYXBwL3BpY3R1cmUvcGljdHVyZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxzQ0FBQTtFQUNBLHNCQUFBO0FDQ0o7O0FERUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSw0REFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7QUNDSjs7QURFQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtBQ0NKOztBREVBO0VBQ0ksZUFBQTtFQUNBLGNBQUE7QUNDSjs7QURFQTtFQUNJLDJCQUFBO0VBQ0EsOEJBQUE7QUNDSjs7QURBSTtFQUNJLFdBQUE7QUNFUjs7QURFQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGFBQUE7QUNDSjs7QURBSTtFQUNJLHlCQUFBO0FDRVI7O0FERUE7RUFDSSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQ0NKOztBREVBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLDREQUFBO0FDQ0oiLCJmaWxlIjoic3JjL2FwcC9waWN0dXJlL3BpY3R1cmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJy4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZycpO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5cclxuaW9uLXRpdGxlIHtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi1idXR0b25zIGlvbi1pY29uIHtcclxuICAgIGZvbnQtc2l6ZTogMjVweDtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG59XHJcblxyXG4ucGljdHVyZV9saXN0IHtcclxuICAgIHBhZGRpbmc6IDAgMjBweDtcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxuXHJcbi5kYXRlX3RleHQge1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICM0ZjRmNGY7XHJcbn1cclxuXHJcbi5waWN0dXJlX2l0ZW1fbGlzdCB7XHJcbiAgICBwYWRkaW5nLXRvcDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAmLS1zZWxlY3RlZCB7XHJcbiAgICAgICAgbWFyZ2luOiA1cHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5waWN0dXJlX3NlbGVjdGVkIHtcclxuICAgIHdpZHRoOiAyMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogOTk7XHJcbiAgICB0b3A6IDBweDtcclxuICAgIGxlZnQ6IDBweDtcclxuICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAmLS1zaG93IHtcclxuICAgICAgICBkaXNwbGF5OiBibG9jayAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4ucGljdHVyZV9fcmRvIHtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxufVxyXG5cclxuLmJ0bi1tYXJrZXQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMTg3YmFkO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogaW5pdGlhbDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNlbnR1cnkgR290aGljIFJlZ3VsYXJcIiwgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG59IiwiaW9uLWhlYWRlciB7XG4gIGJhY2tncm91bmQtaW1hZ2U6IHVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvYmctaGVhZGVyLnBuZ1wiKTtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuaW9uLXRpdGxlIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59XG5cbmlvbi1idXR0b25zIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAyNXB4O1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLnBpY3R1cmVfbGlzdCB7XG4gIHBhZGRpbmc6IDAgMjBweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbn1cblxuLmRhdGVfdGV4dCB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM0ZjRmNGY7XG59XG5cbi5waWN0dXJlX2l0ZW1fbGlzdCB7XG4gIHBhZGRpbmctdG9wOiAwcHggIWltcG9ydGFudDtcbiAgcGFkZGluZy1ib3R0b206IDBweCAhaW1wb3J0YW50O1xufVxuLnBpY3R1cmVfaXRlbV9saXN0LS1zZWxlY3RlZCB7XG4gIG1hcmdpbjogNXB4O1xufVxuXG4ucGljdHVyZV9zZWxlY3RlZCB7XG4gIHdpZHRoOiAyMHB4O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHotaW5kZXg6IDk5O1xuICB0b3A6IDBweDtcbiAgbGVmdDogMHB4O1xuICBkaXNwbGF5OiBub25lO1xufVxuLnBpY3R1cmVfc2VsZWN0ZWQtLXNob3cge1xuICBkaXNwbGF5OiBibG9jayAhaW1wb3J0YW50O1xufVxuXG4ucGljdHVyZV9fcmRvIHtcbiAgb3BhY2l0eTogMDtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB3aWR0aDogMTAwJTtcbiAgaGVpZ2h0OiAxMDAlO1xufVxuXG4uYnRuLW1hcmtldCB7XG4gIC0tYmFja2dyb3VuZDogIzE4N2JhZDtcbiAgd2lkdGg6IDEwMCU7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgdGV4dC10cmFuc2Zvcm06IGluaXRpYWw7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC1mYW1pbHk6IFwiQ2VudHVyeSBHb3RoaWMgUmVndWxhclwiLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XG59Il19 */";
    /***/
  },

  /***/
  "./src/app/picture/picture.page.ts":
  /*!*****************************************!*\
    !*** ./src/app/picture/picture.page.ts ***!
    \*****************************************/

  /*! exports provided: PicturePage */

  /***/
  function srcAppPicturePicturePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PicturePage", function () {
      return PicturePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PicturePage = /*#__PURE__*/function () {
      function PicturePage(platform, navCtrl) {
        _classCallCheck(this, PicturePage);

        this.platform = platform;
        this.navCtrl = navCtrl;
        this.deleteitems = false;
        this.selected_arr = [];
        this.title = "My Picture";
        this.pt_active = false;
      }

      _createClass(PicturePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          if (this.platform.is('android')) {
            this.pt_active = false;
          } else if (this.platform.is('ios')) {
            this.pt_active = true;
          }
        }
      }, {
        key: "goBack",
        value: function goBack() {
          this.navCtrl.pop();
        }
      }, {
        key: "close",
        value: function close() {
          this.deleteitems = false;
          this.title = 'My Picture';
          this.selected_arr = [];
        }
      }, {
        key: "setChecked",
        value: function setChecked(p, s) {
          var found = this.selected_arr.find(function (element) {
            return element.id == p;
          });
          var itemarray = {
            id: p,
            status: s
          };

          if (found) {
            var item_arrs = [itemarray];
            this.selected_arr = this.selected_arr.filter(function (e) {
              return !item_arrs.some(function (s) {
                return s.id === e.id;
              });
            });
          } else {
            this.selected_arr.push(itemarray);
          }

          if (this.selected_arr.length > 0) {
            this.title = this.selected_arr.length + '  selected';
            this.deleteitems = true;
          } else {
            this.title = 'My Picture';
            this.deleteitems = false;
          }
        }
      }, {
        key: "found",
        value: function found(p) {
          var found = this.selected_arr.find(function (element) {
            return element.id == p;
          });

          if (found) {
            return true;
          } else {
            return false;
          }
        }
      }]);

      return PicturePage;
    }();

    PicturePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }];
    };

    PicturePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-picture',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./picture.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/picture/picture.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./picture.page.scss */
      "./src/app/picture/picture.page.scss"))["default"]]
    })], PicturePage);
    /***/
  }
}]);
//# sourceMappingURL=picture-picture-module-es5.js.map